# Hubcity Lore Bible — Phase 3

## 1. World Name

**Vaelmar**

Vaelmar is a low-fantasy frontier realm built over the ruins of an older kingdom. Its people live in bright, practical towns where trade, gossip, and dungeon-diving have become everyday life. Beneath that cozy surface, sealed halls from a dead empire are waking up.

The current playable hub is:

**Brightholm** — a lantern-lit town built around an ancient portal well.

Brightholm feels warm, lived-in, and slightly improvised: market stalls, patched roofs, smith smoke, gossiping townsfolk, and brave idiots calling themselves delvers. The dungeons below are the opposite: cold, oppressive, wet with old magic, and full of things that should have stayed buried.

---

## 2. Central Conflict

Long before Brightholm existed, Vaelmar was ruled by the **Hollow King**, a monarch who tried to preserve his court forever by binding their souls into the stone below the world.

The ritual failed.

His kingdom sank, his court became warped, and the sealed ruins beneath Vaelmar began to dream. Now cracks in the old wards have opened beneath Brightholm. The portal well in the plaza leads into shifting fragments of the Hollow King's buried realm.

The player is not "the chosen one" yet. They are one more armed delver stepping into the portal for coin, gear, and glory — but every dive pulls them closer to the truth: the dungeons are not random caves. They are pieces of a prison coming undone.

---

## 3. Why The Dungeons Exist

The dungeons are called **The Belowholds**.

They are unstable fragments of the Hollow King's sunken kingdom, bleeding upward through old portal seals. Each dive reveals a different arrangement because the Belowholds are not fixed geography; they are memory, stone, and curse grinding against each other.

The portal in Brightholm was originally a **seal**, not a doorway. The town was built around it because the seal was believed dormant. Recently, the seal inverted: instead of keeping the Belowholds shut, it now opens paths into them.

Reasons people still dive:

- **Gold:** old coins, relics, and salvaged weapons sell well.
- **Protection:** every monster killed delays the corruption reaching the surface.
- **Research:** scholars need proof of what lies below.
- **Power:** some factions believe the Hollow King's relics can be used safely.
- **Desperation:** Brightholm's economy now depends on the dive trade.

---

## 4. Tone Guide

### Hub Tone — Brightholm

Reference feel: cozy RuneScape-like hub.

- Warm lanterns, readable silhouettes, friendly NPCs.
- Practical humor and small-town problems.
- NPCs know danger exists, but they cope through routine: forging, trading, banking, gossiping.
- Dialogue should be concise and characterful.
- The hub should feel like a place people live in, not just a menu.

Example hub dialogue style:

> "If the portal starts humming, don't hum back. Fenwick says it encourages the old stones."

### Dungeon Tone — The Belowholds

Reference feel: oppressive, ancient, cursed.

- Damp stone, distant echoes, corrupted creatures.
- The dungeon should feel older than the player understands.
- Bosses are not just monsters; they are fragments of the Hollow King's old court.
- Lore hints should be eerie but not over-explained.

Example dungeon lore style:

> "The crown was grown, not forged. Its roots still remember the king."

---

## 5. Factions

| Faction | Role | Public Face | Hidden Tension |
|---|---|---|---|
| **The Lamplighters** | Keepers of Brightholm's portal seal and town wards. | Helpful protectors who maintain lanterns, wards, and safe paths. | They know the portal was never meant to be used as a doorway. |
| **The Delvers' Compact** | Adventurers, mercenaries, salvage crews, and gear traders. | Practical dive economy: risk below, profit above. | They profit from danger and resist attempts to close the portal. |
| **The Ashen Vow** | Scholars and archivists studying the Hollow King. | Quiet researchers preserving dangerous knowledge. | Some members believe Hollow relics can be controlled. |
| **The Murkmarket** | Informal black-market network for relics, rumors, and questionable goods. | Charming traders and harmless gossipers. | They move cursed items before anyone can inspect them. |

---

## 6. NPC Roster

These six NPCs are the Phase 3 hub cast. All future dialogue, shop, bank, and quest data should reference these IDs.

| ID | Name | Role Label | Faction | Personality One-Liner | Systems Role |
|---|---|---|---|---|---|
| `mara_emberfall` | **Mara Emberfall** | Smith | Delvers' Compact | Blunt, protective, and convinced every problem can be solved with better steel. | Weapon/armor shop; gear tutorial; smithing flavor. |
| `old_fenwick` | **Old Fenwick** | Gate-Warden | Lamplighters | Tired, kind, and deeply worried that everyone treats an ancient seal like a tavern door. | Main quest giver; portal lore; milestone checks. |
| `sister_ilse` | **Sister Ilse** | Archivist | Ashen Vow | Soft-spoken, intense, and more excited by cursed inscriptions than is healthy. | Lore quests; collect quests; Hollow King exposition. |
| `bramble_tung` | **Bramble Tung** | Provisioner | Murkmarket | Cheerful, slippery, and always "accidentally" selling exactly what delvers need. | General shop; buy/sell; potion access. |
| `telleryn` | **Telleryn** | Banker | Delvers' Compact | Immaculately polite, mathematically ruthless, and impossible to surprise. | Bank/storage tutorial; gold flavor. |
| `pip` | **Pip** | Street Scout | Murkmarket | Fast-talking, nosy, and proud owner of every rumor in Brightholm. | Visit quests; rumor hooks; early side quest giver. |

---

## 7. Main Questline Outline

Exactly 8 beats. These beats should become data-driven quests/dialogue flags in later Phase 3 steps. The dungeon loop must remain playable even if the player ignores all of them.

| Beat | Quest ID | Title | Giver | Gate | Narrative Purpose | Reward Intent |
|---|---|---|---|---|---|---|
| 1 | `mq_01_first_lantern` | **The First Lantern** | Old Fenwick | Fresh save / first hub arrival | Introduce Brightholm, the portal seal, and Fenwick's concern. Includes optional intro camera pan. | Small XP/gold; unlock quest tracker tutorial. |
| 2 | `mq_02_belowhold_proof` | **Proof From Below** | Old Fenwick | Complete first dungeon clear OR reach depth 2 | Prove the Belowholds are actively changing and not ordinary ruins. | Gold + potion. |
| 3 | `mq_03_spitter_bile` | **Bile and Bad Omens** | Sister Ilse | Level 3 OR encounter/kill a Spitter | Establish that monsters are adapting and carrying Hollow corruption. | XP + uncommon item chance. |
| 4 | `mq_04_bog_crown` | **The Bog King's Crown** | Old Fenwick | Kill first depth-3 boss, Gulvar | Tie Phase 2 boss into the Hollow King's old court. Gulvar was a crowned herald, not a random beast. | Rare item + main flag `first_crown_taken`. |
| 5 | `mq_05_rift_shards` | **Shards in the Seal** | Sister Ilse | Level 5 OR reach depth 4 | The portal is worsening because pieces of the seal have inverted. | XP + gold. |
| 6 | `mq_06_omen_under_brightholm` | **An Omen Under Brightholm** | Pip → Fenwick | Reach depth 5 | Lightweight omen cut-scene: lanterns flare, portal pulses, a voice from below names the player. | Unlock deeper story dialogue. |
| 7 | `mq_07_second_crown` | **Another Crown Falls** | Mara Emberfall | Kill second boss milestone, depth 6 | Show the Hollow King's court has multiple crowned remnants. Mara frames the threat practically: more crowns mean more war. | Epic-leaning reward roll. |
| 8 | `mq_08_the_sealed_gate` | **The Sealed Gate** | Old Fenwick | Level 8 AND complete Beat 7 | Phase 3 endpoint: identify a deeper sealed gate beneath the Belowholds. Sets up Phase 4 art/content expansion. | Unique item: `lantern_oath_blade`; permanent story flag. |

### Main Quest Rules

- The player can always enter dungeons regardless of main quest state.
- Gates only control dialogue/quest availability, not the core dungeon loop.
- Main quest rewards should help but not invalidate gear progression.
- Beat 8 does not end the game. It opens the next narrative arc.

---

## 8. Side Quest Plan

Six side quests mapped onto the three required templates: kill, collect, visit.

| Quest ID | Title | Template | Giver | Objective | Narrative Flavor | Reward Intent |
|---|---|---|---|---|---|---|
| `sq_kill_slimes_01` | **Gelatinous Housekeeping** | Kill | Mara Emberfall | Kill 8 `slime` enemies. | Slimes have been chewing boot leather and shield straps. Mara wants fewer of them. | Gold + XP. |
| `sq_kill_spitters_01` | **Keep Your Distance** | Kill | Sister Ilse | Kill 5 `spitter` enemies. | Ilse needs confirmation that their bile carries Hollow residue. | XP + lore flag. |
| `sq_collect_rusty_swords_01` | **Blades For The Bellows** | Collect | Mara Emberfall | Collect 2 `rusty_sword` items. | Mara melts bad blades into useful fittings. | Gold + smith discount flag later. |
| `sq_collect_cloth_vests_01` | **Patches For Pip** | Collect | Pip | Collect 2 `cloth_vest` items. | Pip claims they are for "orphans." There is no evidence of this. | Gold + rumor dialogue. |
| `sq_visit_portal_seals_01` | **A Walk Around The Seal** | Visit | Old Fenwick | Visit hub zone `portal_seal_north`, `portal_seal_south`, and `portal_seal_west`. | Fenwick asks the player to inspect the old ward stones around the plaza. | XP + tutorial for visit quests. |
| `sq_visit_depth2_courier_01` | **Courier To The Second Dark** | Visit | Bramble Tung | Visit dungeon zone `depth_2_exit_room`. | Bramble wants a package "delivered" by reaching the deeper exit. The package is never explained. | Gold + potion. |

### Side Quest Rules

- Side quests are optional and repeatable only if explicitly marked later. Default is one-time.
- Objectives must be driven by World events: enemy death, pickup collect, zone enter.
- Quest dialogue should be short and reusable.
- Rewards should not be so large that they replace dungeon loot.

---

## 9. Location Notes

### Brightholm Hub Anchors

Later NPC placement should use these rough anchors:

| Area | Purpose | Suggested NPCs |
|---|---|---|
| Portal plaza | Main quest and dive access. | Old Fenwick |
| Smith stall / forge side | Gear identity and upgrade fantasy. | Mara Emberfall |
| Archive nook / book table | Lore and collect quests. | Sister Ilse |
| Market awning | Consumables and selling. | Bramble Tung |
| Bank counter / sturdy building | Storage and safety. | Telleryn |
| Alley / fountain edge | Rumors and visit quests. | Pip |

### Dungeon Story Anchors

| Anchor | Purpose |
|---|---|
| Spawn room | Safe-ish arrival point; occasional story bark later. |
| Mid-room packs | Enemy objective progress. |
| Exit room | Visit quest target and boss staging. |
| Boss room / final room every 3rd depth | Court remnant encounters. |

---

## 10. Dialogue Voice Guide

### Mara Emberfall

- Short sentences.
- Uses smithing metaphors.
- Protective but not sentimental.

Example:
> "That blade's got more rust than edge. Bring me two like it and I'll make something useful."

### Old Fenwick

- Gentle warnings.
- Speaks like someone who has watched mistakes repeat for years.
- Never dramatic unless the portal is involved.

Example:
> "A door is harmless until it starts choosing who may open it."

### Sister Ilse

- Scholarly, quiet, fascinated.
- Uses precise words.
- Slightly unnerving when discussing cursed things.

Example:
> "The bile is reactive. Not alive, exactly. More like a memory trying to digest itself."

### Bramble Tung

- Salesman energy.
- Friendly, slippery, never directly admits wrongdoing.
- Treats danger as a business opportunity.

Example:
> "If a potion saves your life, friend, was it expensive? Or perfectly priced?"

### Telleryn

- Polished, formal, dry humor.
- Treats banking as sacred order.
- Never hurries.

Example:
> "Your gold is safer here than in your pockets, your boots, or your heroic last words."

### Pip

- Fast, playful, rumor-heavy.
- Knows more than he should.
- Often dodges direct questions.

Example:
> "I didn't steal the rumor. I found it unattended."

---

## 11. Phase 3 Implementation Notes

These notes guide later steps and should remain true:

1. Narrative content belongs in data files:
   - `src/game/data/npcs.ts`
   - `src/game/data/dialogues.ts`
   - `src/game/data/quests.ts`
   - `src/game/data/shops.ts`

2. Logic should reference content by stable IDs:
   - NPC IDs, quest IDs, dialogue node IDs, shop IDs, item IDs, zone IDs.

3. Save migration:
   - Current save is v2.
   - Phase 3 migrates to v3.
   - v3 must preserve:
     - gold
     - depth
     - level
     - XP
     - stat points
     - base stats
     - inventory item IDs
     - equipped weapon/armor IDs

4. New v3 save fields should include:
   - quest states
   - story flags
   - bank inventory
   - optional discovered dialogue/rumor flags

5. Story must never block:
   - entering the portal
   - clearing dungeons
   - collecting loot
   - leveling
   - fighting bosses

6. Main quest gates should only affect:
   - dialogue availability
   - quest acceptance
   - story rewards
   - cinematic moments

---

## 12. Acceptance Criteria For Step 0

- This document defines:
  - world name
  - central conflict
  - why dungeons exist
  - 4 factions
  - tone guide
  - 6 NPCs
  - exactly 8 main quest beats
  - 6 side quests mapped to kill / collect / visit templates

- The content is internally consistent.
- Every later Phase 3 step can source its names, IDs, roles, and quest ideas from this file.
- No TypeScript or runtime code changes are required for Step 0.