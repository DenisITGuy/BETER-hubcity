import * as THREE from 'three';

interface CinematicShot {
  target: THREE.Vector3;
  yaw: number;
  pitch: number;
  distance: number;
}

/**
 * Third-person orbit camera.
 * RMB-drag to orbit, wheel to zoom, smooth-follows a focus point.
 * Optional cinematic override blends to a fixed shot (dialogue framing)
 * and hands control back without a snap on clear.
 */
export class FollowCamera {
  readonly camera = new THREE.PerspectiveCamera(60, 1, 0.1, 300);

  private yaw = Math.PI * 0.25;
  private pitch = 0.6;
  private distance = 7;
  private focus = new THREE.Vector3();
  private shake = 0;
  private cinematic: CinematicShot | null = null;

  constructor(canvas: HTMLCanvasElement) {
    let dragging = false;

    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 2) return;
      dragging = true;
      canvas.setPointerCapture(e.pointerId);
    });

    canvas.addEventListener('pointerup', (e) => {
      dragging = false;
      if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!dragging || this.cinematic) return;
      this.yaw -= e.movementX * 0.004;
      this.pitch = THREE.MathUtils.clamp(this.pitch + e.movementY * 0.003, 0.15, 1.3);
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (this.cinematic) return;
      this.distance = THREE.MathUtils.clamp(this.distance + e.deltaY * 0.008, 3.5, 14);
    }, { passive: false });
  }

  addShake(amount: number): void {
    this.shake = Math.min(this.shake + amount, 0.5);
  }

  getYaw(): number {
    return this.yaw;
  }

  setCinematic(target: THREE.Vector3, yaw: number, pitch: number, distance: number): void {
    this.cinematic = { target: target.clone(), yaw, pitch, distance };
  }

  /** Returns control to the player from the shot's current angles: no snap. */
  clearCinematic(): void {
    this.cinematic = null;
  }

  update(dt: number, target: THREE.Vector3): void {
    if (this.cinematic) {
      const k = 1 - Math.exp(-4 * dt);
      this.focus.lerp(this.cinematic.target, k);
      let d = (this.cinematic.yaw - this.yaw) % (Math.PI * 2);
      if (d > Math.PI) d -= Math.PI * 2;
      if (d < -Math.PI) d += Math.PI * 2;
      this.yaw += d * k;
      this.pitch += (this.cinematic.pitch - this.pitch) * k;
      this.distance += (this.cinematic.distance - this.distance) * k;
    } else {
      this.focus.lerp(target, 1 - Math.exp(-12 * dt));
    }

    const cp = Math.cos(this.pitch);
    const offset = new THREE.Vector3(
      Math.sin(this.yaw) * cp,
      Math.sin(this.pitch),
      Math.cos(this.yaw) * cp,
    ).multiplyScalar(this.distance);

    this.camera.position.copy(this.focus).add(offset);

    if (this.shake > 0.002) {
      const s = this.shake;
      this.camera.position.x += (Math.random() - 0.5) * s;
      this.camera.position.y += (Math.random() - 0.5) * s;
      this.camera.position.z += (Math.random() - 0.5) * s;
      this.shake *= Math.exp(-6 * dt);
    } else {
      this.shake = 0;
    }

    this.camera.lookAt(this.focus.x, this.focus.y + 0.2, this.focus.z);
  }

  resize(aspect: number): void {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }
}