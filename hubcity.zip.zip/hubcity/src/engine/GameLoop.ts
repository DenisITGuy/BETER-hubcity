export class GameLoop {
  private rafId = 0;
  private last = 0;

  constructor(private readonly onFrame: (dt: number) => void) {}

  start(): void {
    this.last = performance.now();
    const tick = (now: number): void => {
      // Clamp dt: no tunneling through walls after a tab-switch.
      const dt = Math.min((now - this.last) / 1000, 1 / 20);
      this.last = now;
      this.onFrame(dt);
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  stop(): void {
    cancelAnimationFrame(this.rafId);
  }
}