/** Keyboard + mouse state tracking with "just pressed" support. */
export class Input {
  private held = new Set<string>();
  private pressedThisFrame = new Set<string>();

  constructor() {
    window.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      this.held.add(e.code);
      this.pressedThisFrame.add(e.code);
      if (e.code === 'Space') e.preventDefault();
    });
    window.addEventListener('keyup', (e) => this.held.delete(e.code));
    window.addEventListener('blur', () => this.held.clear());
  }

  /** Tracks mouse buttons on an element as Mouse0/Mouse1/Mouse2. */
  attachMouse(el: HTMLElement): void {
    el.addEventListener('pointerdown', (e) => {
      const code = `Mouse${e.button}`;
      this.held.add(code);
      this.pressedThisFrame.add(code);
    });
    window.addEventListener('pointerup', (e) => this.held.delete(`Mouse${e.button}`));
  }

  isHeld(code: string): boolean {
    return this.held.has(code);
  }

  wasPressed(code: string): boolean {
    return this.pressedThisFrame.has(code);
  }

  /** Call once at the end of every frame. */
  endFrame(): void {
    this.pressedThisFrame.clear();
  }
}