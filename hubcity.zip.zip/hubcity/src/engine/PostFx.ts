import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

/**
 * Bloom + output pass. Torches, visors, portals and particles glow for real.
 * Uses three's own addons — no new dependencies.
 */
export class PostFX {
  private readonly composer: EffectComposer;

  constructor(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera, w: number, h: number) {
    this.composer = new EffectComposer(renderer);
    this.composer.addPass(new RenderPass(scene, camera));
    // strength, radius, threshold — only bright/emissive things bloom.
    this.composer.addPass(new UnrealBloomPass(new THREE.Vector2(w / 2, h / 2), 0.55, 0.55, 0.72));
    this.composer.addPass(new OutputPass());
  }

  render(): void {
    this.composer.render();
  }

  resize(w: number, h: number): void {
    this.composer.setSize(w, h);
  }
}