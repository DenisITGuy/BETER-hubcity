import * as THREE from 'three';
import { getGlowTexture } from './Fx';

const HALF = 10;   // recycle radius around the player
const SIZE = HALF * 2;

/** Star dome + world-space dust motes that recycle around the player. */
export class Atmosphere {
  readonly group = new THREE.Group();
  private readonly stars: THREE.Points;
  private readonly motes: THREE.Points;
  private readonly motePos: Float32Array;
  private readonly moteSpeed: Float32Array;
  private time = 0;

  constructor() {
    // Stars on the upper dome (fixed in world space, far away).
    const starCount = 320;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const a = Math.random() * Math.PI * 2;
      const y = 0.15 + Math.random() * 0.85;
      const r = Math.sqrt(1 - y * y);
      starPos[i * 3] = Math.cos(a) * r * 150;
      starPos[i * 3 + 1] = y * 150;
      starPos[i * 3 + 2] = Math.sin(a) * r * 150;
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    this.stars = new THREE.Points(
      starGeo,
      new THREE.PointsMaterial({
        size: 1.1, map: getGlowTexture(), color: 0xaabbff, transparent: true,
        opacity: 0.75, depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
      }),
    );
    this.group.add(this.stars);

    // Dust motes, world-space coordinates.
    const moteCount = 140;
    this.motePos = new Float32Array(moteCount * 3);
    this.moteSpeed = new Float32Array(moteCount);
    for (let i = 0; i < moteCount; i++) {
      this.motePos[i * 3] = (Math.random() - 0.5) * SIZE;
      this.motePos[i * 3 + 1] = Math.random() * 6;
      this.motePos[i * 3 + 2] = (Math.random() - 0.5) * SIZE;
      this.moteSpeed[i] = 0.15 + Math.random() * 0.35;
    }
    const moteGeo = new THREE.BufferGeometry();
    moteGeo.setAttribute('position', new THREE.BufferAttribute(this.motePos, 3));
    this.motes = new THREE.Points(
      moteGeo,
      new THREE.PointsMaterial({
        size: 0.14, map: getGlowTexture(), color: 0xffcc88, transparent: true,
        opacity: 0.35, depthWrite: false, blending: THREE.AdditiveBlending,
      }),
    );
    // Container NEVER moves — particles are true world-space.
    this.group.add(this.motes);
  }

  update(dt: number, center: THREE.Vector3): void {
    this.time += dt;
    this.stars.rotation.y += dt * 0.004;

    for (let i = 0; i < this.moteSpeed.length; i++) {
      let x = this.motePos[i * 3];
      let y = this.motePos[i * 3 + 1];
      let z = this.motePos[i * 3 + 2];

      // Wind drift + gentle sway + upward float, all in world space.
      x += dt * 0.8;
      z += Math.sin(this.time * 0.4 + i * 0.5) * dt * 0.2;
      y += this.moteSpeed[i] * dt;
      if (y > 6) y -= 6;

      // Recycle: keep each mote within HALF meters of the player by wrapping
      // its offset. Modulo handles any distance, including portal teleports.
      let dx = x - center.x;
      dx = ((((dx + HALF) % SIZE) + SIZE) % SIZE) - HALF;
      x = center.x + dx;

      let dz = z - center.z;
      dz = ((((dz + HALF) % SIZE) + SIZE) % SIZE) - HALF;
      z = center.z + dz;

      this.motePos[i * 3] = x;
      this.motePos[i * 3 + 1] = y;
      this.motePos[i * 3 + 2] = z;
    }
    (this.motes.geometry.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
  }
}