import * as THREE from 'three';

/** Anything that can push a moving circle out of solid space. */
export interface CircleCollider {
  collideCircle(pos: THREE.Vector3, radius: number): void;
}