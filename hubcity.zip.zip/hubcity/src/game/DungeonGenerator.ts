export const TILE = 2; // meters per grid tile

export interface Room {
  x: number;
  y: number;
  w: number;
  h: number;
  centerX: number;
  centerY: number;
}

export interface DungeonData {
  seed: number;
  width: number;
  height: number;
  /** Row-major: tiles[y * width + x]. 1 = walkable floor, 0 = solid. */
  tiles: Uint8Array;
  rooms: Room[];
  spawnX: number;
  spawnY: number;
}

/** Deterministic PRNG — same seed always yields the same dungeon. Pays off in Phase 5 (daily runs). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface GeneratorOptions {
  width?: number;
  height?: number;
  roomCount?: number;
}

/** Room-and-corridor generator: scatter rooms, stitch them with L-corridors (guaranteed connectivity). */
export function generateDungeon(seed: number, opts: GeneratorOptions = {}): DungeonData {
  const width = opts.width ?? 44;
  const height = opts.height ?? 44;
  const roomTarget = opts.roomCount ?? 8;
  const rand = mulberry32(seed);

  const tiles = new Uint8Array(width * height); // 0 = solid
  const rooms: Room[] = [];

  const carve = (x: number, y: number): void => {
    if (x > 0 && y > 0 && x < width - 1 && y < height - 1) tiles[y * width + x] = 1;
  };

  const carveRect = (x: number, y: number, w: number, h: number): void => {
    for (let ty = y; ty < y + h; ty++) for (let tx = x; tx < x + w; tx++) carve(tx, ty);
  };

  let attempts = 0;
  while (rooms.length < roomTarget && attempts < 400) {
    attempts++;
    const w = 4 + Math.floor(rand() * 6); // 4..9 tiles
    const h = 4 + Math.floor(rand() * 6);
    const x = 1 + Math.floor(rand() * (width - w - 2));
    const y = 1 + Math.floor(rand() * (height - h - 2));
    rooms.push({
      x, y, w, h,
      centerX: Math.floor(x + w / 2),
      centerY: Math.floor(y + h / 2),
    });
    carveRect(x, y, w, h);
  }

  // Safety net (should never trigger with these bounds).
  if (rooms.length === 0) {
    rooms.push({ x: 4, y: 4, w: 6, h: 6, centerX: 7, centerY: 7 });
    carveRect(4, 4, 6, 6);
  }

  // 2-wide corridors, connect each room to the previous one.
  for (let i = 1; i < rooms.length; i++) {
    const a = rooms[i - 1];
    const b = rooms[i];
    let x = a.centerX;
    let y = a.centerY;

    const digH = (): void => {
      const step = Math.sign(b.centerX - x);
      while (x !== b.centerX) { carve(x, y); carve(x, y + 1); x += step; }
    };
    const digV = (): void => {
      const step = Math.sign(b.centerY - y);
      while (y !== b.centerY) { carve(x, y); carve(x + 1, y); y += step; }
    };

    if (rand() < 0.5) { digH(); digV(); } else { digV(); digH(); }
    carve(x, y); carve(x + 1, y); carve(x, y + 1);
  }

  return {
    seed, width, height, tiles, rooms,
    spawnX: rooms[0].centerX,
    spawnY: rooms[0].centerY,
  };
}