import * as THREE from 'three';
import { DungeonData, Room, TILE, mulberry32 } from './DungeonGenerator';
import { makeGlow } from './Fx';

const WALL_HEIGHT = 3;

interface Torch {
  flame: THREE.MeshStandardMaterial;
  glow: THREE.Sprite;
  baseScale: number;
  phase: number;
}

export class DungeonMesh {
  readonly group = new THREE.Group();

  private readonly roundSolids: Array<{ x: number; z: number; r: number }> = [];
  private readonly torches: Torch[] = [];
  private time = 0;

  constructor(private readonly data: DungeonData) {
    this.buildFloor();
    this.buildWalls();
    this.buildTorches();
  }

  get rooms(): Room[] {
    return this.data.rooms;
  }

  /** Flicker torches. Called by World each dungeon frame. */
  update(dt: number): void {
    this.time += dt;
    for (const t of this.torches) {
      const f = Math.sin(this.time * 12 + t.phase) * 0.35 + Math.sin(this.time * 23 + t.phase * 2) * 0.15;
      t.flame.emissiveIntensity = 1.7 + f;
      const mat = t.glow.material as THREE.SpriteMaterial;
      mat.opacity = 0.55 + f * 0.15;
      t.glow.scale.setScalar(t.baseScale * (1 + f * 0.06));
    }
  }

  gridToWorld(gx: number, gy: number): THREE.Vector3 {
    return new THREE.Vector3(
      (gx + 0.5 - this.data.width / 2) * TILE,
      0,
      (gy + 0.5 - this.data.height / 2) * TILE,
    );
  }

  worldToGrid(wx: number, wz: number): { x: number; y: number } {
    return {
      x: Math.floor(wx / TILE + this.data.width / 2),
      y: Math.floor(wz / TILE + this.data.height / 2),
    };
  }

  isSolidGrid(gx: number, gy: number): boolean {
    if (gx < 0 || gy < 0 || gx >= this.data.width || gy >= this.data.height) return true;
    return this.data.tiles[gy * this.data.width + gx] === 0;
  }

  isSolidWorld(wx: number, wz: number): boolean {
    const g = this.worldToGrid(wx, wz);
    return this.isSolidGrid(g.x, g.y);
  }

  collideCircle(pos: THREE.Vector3, radius: number): void {
    const min = this.worldToGrid(pos.x - radius, pos.z - radius);
    const max = this.worldToGrid(pos.x + radius, pos.z + radius);

    for (let gy = min.y; gy <= max.y; gy++) {
      for (let gx = min.x; gx <= max.x; gx++) {
        if (!this.isSolidGrid(gx, gy)) continue;

        const c = this.gridToWorld(gx, gy);
        const half = TILE / 2;
        const minX = c.x - half;
        const maxX = c.x + half;
        const minZ = c.z - half;
        const maxZ = c.z + half;

        const nearX = THREE.MathUtils.clamp(pos.x, minX, maxX);
        const nearZ = THREE.MathUtils.clamp(pos.z, minZ, maxZ);
        const dx = pos.x - nearX;
        const dz = pos.z - nearZ;
        const distSq = dx * dx + dz * dz;

        if (distSq >= radius * radius) continue;

        if (distSq < 1e-8) {
          const left = pos.x - minX;
          const right = maxX - pos.x;
          const up = pos.z - minZ;
          const down = maxZ - pos.z;
          const m = Math.min(left, right, up, down);
          if (m === left) pos.x = minX - radius;
          else if (m === right) pos.x = maxX + radius;
          else if (m === up) pos.z = minZ - radius;
          else pos.z = maxZ - radius;
          continue;
        }

        const dist = Math.sqrt(distSq);
        const push = (radius - dist) / dist;
        pos.x += dx * push;
        pos.z += dz * push;
      }
    }

    // Braziers and props.
    for (const c of this.roundSolids) {
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      const d = Math.hypot(dx, dz);
      const minD = c.r + radius;
      if (d >= minD || d < 1e-6) continue;
      const push = (minD - d) / d;
      pos.x += dx * push;
      pos.z += dz * push;
    }
  }

  hasLineOfSight(a: THREE.Vector3, b: THREE.Vector3): boolean {
    const dist = Math.hypot(b.x - a.x, b.z - a.z);
    const steps = Math.max(1, Math.ceil(dist / 0.5));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      if (this.isSolidWorld(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t)) return false;
    }
    return true;
  }

  randomPointInRoom(room: Room): THREE.Vector3 {
    const gx = room.x + Math.floor(Math.random() * room.w);
    const gy = room.y + Math.floor(Math.random() * room.h);
    return this.gridToWorld(gx, gy);
  }

  private buildFloor(): void {
    const w = this.data.width * TILE;
    const h = this.data.height * TILE;

    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      new THREE.MeshStandardMaterial({ color: 0x2e3446, roughness: 0.95 }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.group.add(floor);
  }

  private buildWalls(): void {
    const { width, height, tiles } = this.data;
    const isFloor = (x: number, y: number): boolean =>
      x >= 0 && y >= 0 && x < width && y < height && tiles[y * width + x] === 1;

    const spots: Array<{ x: number; y: number }> = [];
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        if (tiles[y * width + x] === 1) continue;
        if (isFloor(x + 1, y) || isFloor(x - 1, y) || isFloor(x, y + 1) || isFloor(x, y - 1)) {
          spots.push({ x, y });
        }
      }
    }

    const walls = new THREE.InstancedMesh(
      new THREE.BoxGeometry(TILE, WALL_HEIGHT, TILE),
      new THREE.MeshStandardMaterial({ color: 0x8a8f9c, roughness: 0.95 }),
      spots.length,
    );
    walls.castShadow = true;
    walls.receiveShadow = true;

    const m = new THREE.Matrix4();
    const color = new THREE.Color();
    spots.forEach((s, i) => {
      const p = this.gridToWorld(s.x, s.y);
      m.makeTranslation(p.x, WALL_HEIGHT / 2, p.z);
      walls.setMatrixAt(i, m);
      walls.setColorAt(i, color.setHSL(0.62, 0.1, 0.4 + ((s.x * 7 + s.y * 13) % 5) * 0.03));
    });
    walls.instanceMatrix.needsUpdate = true;
    if (walls.instanceColor) walls.instanceColor.needsUpdate = true;

    this.group.add(walls);
  }

  /** Two braziers per room at opposite corners: light, warmth, landmarks. */
  private buildTorches(): void {
    const rand = mulberry32((this.data.seed ^ 0x5eed) >>> 0);
    const postMat = new THREE.MeshStandardMaterial({ color: 0x3a3f4a, roughness: 0.8, metalness: 0.4 });

    for (const room of this.data.rooms) {
      const corners: Array<[number, number]> = [
        [room.x, room.y],
        [room.x + room.w - 1, room.y + room.h - 1],
      ];
      for (const [gx, gy] of corners) {
        const p = this.gridToWorld(gx, gy);

        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.15, 0.85, 8), postMat);
        post.position.set(p.x, 0.42, p.z);
        post.castShadow = true;
        this.group.add(post);

        const flameMat = new THREE.MeshStandardMaterial({
          color: 0x331100, emissive: 0xff7722, emissiveIntensity: 1.7,
        });
        const flame = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.42, 8), flameMat);
        flame.position.set(p.x, 1.05, p.z);
        this.group.add(flame);

        const baseScale = 2.4;
        const glow = makeGlow(0xff8833, baseScale);
        glow.position.set(p.x, 1.1, p.z);
        this.group.add(glow);

        this.torches.push({ flame: flameMat, glow, baseScale, phase: rand() * 10 });
        this.roundSolids.push({ x: p.x, z: p.z, r: 0.25 });
      }
    }
  }
}