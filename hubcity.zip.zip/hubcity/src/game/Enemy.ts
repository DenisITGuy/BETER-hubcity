import * as THREE from 'three';
import { DungeonMesh } from './DungeonMesh';
import { Player } from './Player';
import { Room } from './DungeonGenerator';
import { lerpAngle } from './math';
import { ENEMY_BASE } from './data/tunables';
import { EnemyDefinition } from './data/schemas';
import { attachOutline } from './Fx';

export type EnemyState = 'patrol' | 'chase' | 'windup' | 'recover' | 'charge' | 'dead';

/** World implements this so enemies stay presentation-free. */
export interface EnemyEvents {
  spawnProjectile(x: number, z: number, dirX: number, dirZ: number, speed: number, damage: number, color: number): void;
  slamHit(pos: THREE.Vector3, radius: number, damage: number): void;
}

const REST_SCALE = new THREE.Vector3(1, ENEMY_BASE.restYSquash, 1);

export class Enemy {
  readonly object = new THREE.Group();
  readonly radius: number;
  readonly def: EnemyDefinition;
  readonly maxHealth: number;
  health: number;

  state: EnemyState = 'patrol';
  lootDropped = false;
  /** True for one frame when a windup begins; World draws telegraphs. */
  windupStarted = false;

  private stateTime = 0;
  private age = 0;
  private deathTime = 0;
  private hitFlash = 0;
  private pattern = 0;
  private chargeHitDone = false;
  private readonly chargeDir = new THREE.Vector3(0, 0, -1);
  private readonly tmpV = new THREE.Vector3();
  private readonly bobSeed = Math.random() * Math.PI * 2;
  private readonly targetPoint = new THREE.Vector3();
  private readonly home: Room;

  private readonly mat: THREE.MeshStandardMaterial;
  private readonly bodyMesh: THREE.Mesh;
  private readonly baseColor: THREE.Color;
  private readonly warnColor = new THREE.Color(0xff4433);
  private readonly restY: number;

  constructor(def: EnemyDefinition, room: Room, spawn: THREE.Vector3) {
    this.def = def;
    this.health = def.health;
    this.maxHealth = def.health;
    this.radius = ENEMY_BASE.radius * def.scale;
    this.home = room;
    this.object.position.copy(spawn);
    this.targetPoint.copy(spawn);
    this.baseColor = new THREE.Color(def.color);

    const r = this.radius;
    this.restY = r * 0.93;

    this.mat = new THREE.MeshStandardMaterial({ color: this.baseColor.clone(), roughness: 0.5, flatShading: true });
    this.bodyMesh = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 12), this.mat);
    this.bodyMesh.position.y = this.restY;
    this.bodyMesh.scale.copy(REST_SCALE);
    this.bodyMesh.castShadow = true;
    attachOutline(this.bodyMesh, 1.07);
    this.object.add(this.bodyMesh);

    // Eyes
    const eyeGeo = new THREE.SphereGeometry(0.07 * def.scale, 8, 8);
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x141422 });
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.16 * def.scale, 0.13 * def.scale, -0.39 * def.scale);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.16 * def.scale, 0.13 * def.scale, -0.39 * def.scale);
    this.bodyMesh.add(eyeL, eyeR);

    // Brutes & bosses get rock spikes; the boss gets a crown.
    if (def.archetype === 'brute' || def.archetype === 'boss') {
      const spikeMat = new THREE.MeshStandardMaterial({ color: 0x6b6f7a, roughness: 0.9, flatShading: true });
      for (const sx of [-0.22, 0.22]) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.12 * def.scale, 0.45 * def.scale, 6), spikeMat);
        spike.position.set(sx * def.scale, r * 1.35, 0.1 * def.scale);
        spike.rotation.x = 0.5;
        this.bodyMesh.add(spike);
      }
    }
    if (def.archetype === 'boss') {
      const crownMat = new THREE.MeshStandardMaterial({ color: 0xffd166, roughness: 0.3, metalness: 0.7, flatShading: true });
      for (const cx of [-0.16, 0, 0.16]) {
        const point = new THREE.Mesh(new THREE.ConeGeometry(0.08 * def.scale, 0.3 * def.scale, 5), crownMat);
        point.position.set(cx * def.scale, r * 1.85, 0);
        this.bodyMesh.add(point);
      }
    }
  }

  get isDead(): boolean {
    return this.state === 'dead';
  }

  get healthFrac(): number {
    return Math.max(0, this.health / this.maxHealth);
  }

  get bossPattern(): number {
    return this.pattern;
  }

  takeHit(amount: number): boolean {
    if (this.isDead) return false;
    this.health -= amount;
    this.hitFlash = ENEMY_BASE.hitFlashTime;
    if (this.health <= 0) {
      this.setState('dead');
      return true;
    }
    // Only light enemies flinch; brutes and bosses power through.
    if (this.state === 'windup' && (this.def.archetype === 'melee' || this.def.archetype === 'spitter')) {
      this.setState('chase');
    }
    return false;
  }

  update(dt: number, dungeon: DungeonMesh, player: Player, events: EnemyEvents): boolean {
    this.age += dt;
    this.windupStarted = false;

    if (this.hitFlash > 0) {
      this.hitFlash -= dt;
      this.mat.emissive.setScalar(Math.max(0, this.hitFlash) * 3);
    } else {
      this.mat.emissive.setScalar(0);
    }

    if (this.state === 'dead') {
      this.deathTime += dt;
      const s = Math.max(0, 1 - this.deathTime / ENEMY_BASE.deathTime);
      this.object.scale.set(1 + (1 - s) * 0.4, s, 1 + (1 - s) * 0.4);
      return s <= 0;
    }

    this.stateTime += dt;
    const myPos = this.object.position;
    this.tmpV.subVectors(player.object.position, myPos);
    this.tmpV.y = 0;
    const dist = this.tmpV.length();
    const seesPlayer =
      !player.isDead &&
      dist < this.def.detectRange &&
      dungeon.hasLineOfSight(myPos, player.object.position);

    const a = this.def.archetype;

    switch (this.state) {
      case 'patrol': {
        if (myPos.distanceTo(this.targetPoint) < 0.4 || this.stateTime > ENEMY_BASE.patrolRetargetTime) {
          this.targetPoint.copy(dungeon.randomPointInRoom(this.home));
          this.stateTime = 0;
        }
        this.moveToward(this.targetPoint, this.def.speed * ENEMY_BASE.patrolSpeedFactor, dt, dungeon);
        if (seesPlayer) this.setState('chase');
        break;
      }

      case 'chase': {
        if (player.isDead) {
          this.setState('patrol');
          break;
        }
        if (a === 'spitter') {
          const pref = this.def.preferredRange ?? 6;
          if (dist < pref * 0.6) {
            // Back away to firing range.
            const dir = this.tmpV.clone().normalize().multiplyScalar(-1);
            this.step(dir, this.def.speed, dt, dungeon);
          } else if (dist > pref) {
            this.moveToward(player.object.position, this.def.speed, dt, dungeon);
          }
          if (seesPlayer && dist >= 2) this.setState('windup');
          if (dist > this.def.detectRange * ENEMY_BASE.leashMultiplier) this.setState('patrol');
        } else {
          if (dist <= this.def.attackRange) {
            this.setState('windup');
            break;
          }
          if (dist > this.def.detectRange * ENEMY_BASE.leashMultiplier) {
            this.setState('patrol');
            break;
          }
          this.moveToward(player.object.position, this.def.speed, dt, dungeon);
        }
        break;
      }

      case 'windup': {
        const t = Math.min(1, this.stateTime / this.def.windupTime);
        this.mat.color.copy(this.baseColor).lerp(this.warnColor, t);
        this.bodyMesh.scale.set(
          1 + t * ENEMY_BASE.telegraphScale,
          ENEMY_BASE.restYSquash * (1 + t * ENEMY_BASE.telegraphYScale),
          1 + t * ENEMY_BASE.telegraphScale,
        );
        if (this.stateTime >= this.def.windupTime) {
          const charged = this.fire(events, player, myPos, dist);
          this.mat.color.copy(this.baseColor);
          if (!charged) this.setState('recover');
        }
        break;
      }

      case 'recover': {
        this.bodyMesh.scale.lerp(REST_SCALE, 1 - Math.exp(-12 * dt));
        if (this.stateTime >= this.def.recoverTime) this.setState('chase');
        break;
      }

      case 'charge': {
        const ct = this.def.chargeTime ?? 0.5;
        const cs = this.def.chargeSpeed ?? 9;
        myPos.addScaledVector(this.chargeDir, cs * dt);
        dungeon.collideCircle(myPos, this.radius);
        this.object.rotation.y = Math.atan2(-this.chargeDir.x, -this.chargeDir.z);
        if (!this.chargeHitDone && dist < this.radius + player.radius + 0.2) {
          player.takeDamage(this.def.damage);
          this.chargeHitDone = true;
        }
        if (this.stateTime >= ct) this.setState('recover');
        break;
      }
    }

    // Locomotion feel: jelly squash for light enemies, heavy stomp for big ones.
    const moving = this.state === 'patrol' || this.state === 'chase' || this.state === 'charge';
    if (a === 'melee' || a === 'spitter') {
      const hop = Math.abs(Math.sin(this.age * ENEMY_BASE.hopFrequency + this.bobSeed));
      this.bodyMesh.position.y = this.restY + (moving ? hop * ENEMY_BASE.hopHeight : 0);
        if (moving) {
        const sq = 1 - hop * 0.12;
        this.bodyMesh.scale.x = sq;
        this.bodyMesh.scale.z = sq;
        if (this.state !== 'windup') this.bodyMesh.scale.y = ENEMY_BASE.restYSquash * (1 + hop * 0.25);
      }
    } else {
      this.bodyMesh.position.y = this.restY + (moving ? Math.abs(Math.sin(this.age * 4 + this.bobSeed)) * 0.05 * this.def.scale : 0);
    }

    const minDist = this.radius + ENEMY_BASE.separation;
    if (!player.isDead && dist < minDist && dist > 1e-4 && this.state !== 'charge') {
      myPos.addScaledVector(this.tmpV.clone().normalize(), -(minDist - dist));
    }

    return false;
  }

  /** Resolve the attack at windup end. Returns true if it entered a charge. */
  private fire(events: EnemyEvents, player: Player, myPos: THREE.Vector3, dist: number): boolean {
    const a = this.def.archetype;

    if (a === 'melee') {
      if (dist <= this.def.attackRange + this.def.strikeRangeBonus) player.takeDamage(this.def.damage);
      return false;
    }

    if (a === 'spitter') {
      const dx = player.object.position.x - myPos.x;
      const dz = player.object.position.z - myPos.z;
      const d = Math.hypot(dx, dz) || 1;
      events.spawnProjectile(myPos.x, myPos.z, dx / d, dz / d, this.def.projectileSpeed ?? 9, this.def.damage, this.def.color);
      return false;
    }

    if (a === 'brute') {
      events.slamHit(myPos, this.def.slamRadius ?? 2.5, this.def.damage);
      return false;
    }

    // Boss: pattern 0 = slam, 1 = volley, 2 = charge (chosen at windup start).
    if (this.pattern === 0) {
      events.slamHit(myPos, this.def.slamRadius ?? 3, this.def.damage);
    } else if (this.pattern === 1) {
      const dx = player.object.position.x - myPos.x;
      const dz = player.object.position.z - myPos.z;
      const base = Math.atan2(dz, dx);
      for (const off of [-0.28, 0, 0.28]) {
        events.spawnProjectile(myPos.x, myPos.z, Math.cos(base + off), Math.sin(base + off), this.def.projectileSpeed ?? 8, this.def.damage, this.def.color);
      }
    } else {
      this.chargeDir.set(player.object.position.x - myPos.x, 0, player.object.position.z - myPos.z);
      if (this.chargeDir.lengthSq() > 1e-6) this.chargeDir.normalize();
      this.chargeHitDone = false;
      this.setState('charge');
      return true;
    }
    return false;
  }

  private setState(state: EnemyState): void {
    if (state === 'windup') {
      this.windupStarted = true;
      if (this.def.archetype === 'boss') this.pattern = (this.pattern + 1) % 3;
    }
    this.state = state;
    this.stateTime = 0;
  }

  private step(dir: THREE.Vector3, speed: number, dt: number, dungeon: DungeonMesh): void {
    const pos = this.object.position;
    const stepLen = speed * dt;
    pos.x += dir.x * stepLen;
    dungeon.collideCircle(pos, this.radius);
    pos.z += dir.z * stepLen;
    dungeon.collideCircle(pos, this.radius);
  }

  private moveToward(target: THREE.Vector3, speed: number, dt: number, dungeon: DungeonMesh): void {
    const pos = this.object.position;
    const dir = this.tmpV.set(target.x - pos.x, 0, target.z - pos.z);
    const d = dir.length();
    if (d < 0.05) return;
    dir.multiplyScalar(1 / d);
    this.step(dir, speed, dt, dungeon);
    const targetYaw = Math.atan2(-dir.x, -dir.z);
    this.object.rotation.y = lerpAngle(this.object.rotation.y, targetYaw, 1 - Math.exp(-ENEMY_BASE.turnSmoothing * dt));
  }
}