import * as THREE from 'three';

let glowTexture: THREE.Texture | null = null;

/** Radial-gradient glow texture, generated once at runtime (no external assets). */
export function getGlowTexture(): THREE.Texture {
  if (glowTexture) return glowTexture;
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.35, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  glowTexture = new THREE.CanvasTexture(canvas);
  return glowTexture;
}

/** Additive glow billboard for torches, lanterns, beams. */
export function makeGlow(color: number, scale: number): THREE.Sprite {
  const mat = new THREE.SpriteMaterial({
    map: getGlowTexture(),
    color,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const s = new THREE.Sprite(mat);
  s.scale.setScalar(scale);
  return s;
}

/** Stylized inverted-hull outline. Big cartoon win for zero asset cost. */
export function attachOutline(mesh: THREE.Mesh, scale = 1.08): void {
  const mat = new THREE.MeshBasicMaterial({ color: 0x0a0c12, side: THREE.BackSide });
  const outline = new THREE.Mesh(mesh.geometry, mat);
  outline.scale.setScalar(scale);
  mesh.add(outline);
}

interface Particle {
  sprite: THREE.Sprite;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  size: number;
  gravity: number;
  active: boolean;
}

interface Ring {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  life: number;
  maxLife: number;
  grow: number;
  active: boolean;
}

const POOL_SIZE = 140;
const RING_POOL = 8;

/** Pooled additive particles + shockwave rings. Zero steady-state allocations. */
export class Fx {
  readonly group = new THREE.Group();
  private readonly particles: Particle[] = [];
  private readonly rings: Ring[] = [];

  constructor() {
    const tex = getGlowTexture();
    for (let i = 0; i < POOL_SIZE; i++) {
      const mat = new THREE.SpriteMaterial({
        map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      });
      const sprite = new THREE.Sprite(mat);
      sprite.visible = false;
      this.group.add(sprite);
      this.particles.push({ sprite, vel: new THREE.Vector3(), life: 0, maxLife: 1, size: 1, gravity: 0, active: false });
    }
    const ringGeo = new THREE.RingGeometry(0.9, 1, 40);
    for (let i = 0; i < RING_POOL; i++) {
      const mat = new THREE.MeshBasicMaterial({
        transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
      });
      const mesh = new THREE.Mesh(ringGeo, mat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.visible = false;
      this.group.add(mesh);
      this.rings.push({ mesh, mat, life: 0, maxLife: 1, grow: 8, active: false });
    }
  }

  burst(pos: THREE.Vector3, color: number, count: number, speed = 3, life = 0.5, size = 0.5, gravity = -6): void {
    let spawned = 0;
    for (const p of this.particles) {
      if (spawned >= count) break;
      if (p.active) continue;
      spawned++;
      p.active = true;
      p.life = 0;
      p.maxLife = life * (0.7 + Math.random() * 0.6);
      p.size = size * (0.7 + Math.random() * 0.6);
      p.gravity = gravity;
      p.sprite.visible = true;
      p.sprite.position.copy(pos);
      p.sprite.material.color.set(color);
      p.sprite.material.opacity = 1;
      const a = Math.random() * Math.PI * 2;
      const up = Math.random() * 0.8 + 0.2;
      p.vel.set(
        Math.cos(a) * speed * (0.4 + Math.random() * 0.6),
        up * speed,
        Math.sin(a) * speed * (0.4 + Math.random() * 0.6),
      );
    }
  }

  ring(pos: THREE.Vector3, color: number, grow = 8, life = 0.35, y = 0.15): void {
    for (const r of this.rings) {
      if (r.active) continue;
      r.active = true;
      r.life = 0;
      r.maxLife = life;
      r.grow = grow;
      r.mesh.visible = true;
      r.mesh.position.set(pos.x, y, pos.z);
      r.mesh.scale.setScalar(0.4);
      r.mat.color.set(color);
      r.mat.opacity = 0.9;
      return;
    }
  }

  update(dt: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life += dt;
      const t = p.life / p.maxLife;
      if (t >= 1) {
        p.active = false;
        p.sprite.visible = false;
        continue;
      }
      p.vel.y += p.gravity * dt;
      p.sprite.position.addScaledVector(p.vel, dt);
      p.sprite.material.opacity = 1 - t;
      p.sprite.scale.setScalar(p.size * (1 - t * 0.5));
    }
    for (const r of this.rings) {
      if (!r.active) continue;
      r.life += dt;
      const t = r.life / r.maxLife;
      if (t >= 1) {
        r.active = false;
        r.mesh.visible = false;
        continue;
      }
      r.mesh.scale.setScalar(0.4 + t * r.grow);
      r.mat.opacity = 0.9 * (1 - t);
    }
  }
}