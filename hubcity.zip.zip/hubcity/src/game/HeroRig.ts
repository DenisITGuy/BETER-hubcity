import * as THREE from 'three';
import { attachOutline } from './Fx';

export type CastKind = 'none' | 'whirl' | 'mend';

export interface RigState {
  age: number;
  moving: boolean;
  move01: number;
  attackT: number;
  dodgeT: number;
  rushT: number;
  hurtT: number;
  deadT: number;
  castT: number;
  castKind: CastKind;
}

/**
 * Procedural stylized hero rig + code-driven animator.
 * Joint hierarchy is built so a future Mixamo/glTF swap only replaces meshes,
 * not the state hooks (idle/move/attack/dodge/hurt/dead/cast).
 */
export class HeroRig {
  readonly root = new THREE.Group();
  readonly weaponSocket = new THREE.Group();

  private readonly hips = new THREE.Group();
  private readonly torso = new THREE.Group();
  private readonly head = new THREE.Group();
  private readonly armL = new THREE.Group();
  private readonly armR = new THREE.Group();
  private readonly legL = new THREE.Group();
  private readonly legR = new THREE.Group();
  private readonly cape: THREE.Mesh;

  private readonly armorMat: THREE.MeshStandardMaterial;
  private readonly metalMat: THREE.MeshStandardMaterial;
  private walkPhase = 0;

  constructor() {
    this.armorMat = new THREE.MeshStandardMaterial({ color: 0x3fa7ff, roughness: 0.55, flatShading: true });
    this.metalMat = new THREE.MeshStandardMaterial({ color: 0x8f97a6, roughness: 0.4, metalness: 0.6, flatShading: true });
    const clothMat = new THREE.MeshStandardMaterial({ color: 0x8a2f3a, roughness: 0.9, side: THREE.DoubleSide });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x2c3038, roughness: 0.8, flatShading: true });
    const visorMat = new THREE.MeshStandardMaterial({ color: 0x06131f, emissive: 0x66ddff, emissiveIntensity: 2.2 });

    // Hips + legs
    this.hips.position.y = 0.78;
    this.root.add(this.hips);
    const hipsMesh = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.22, 0.24), darkMat);
    attachOutline(hipsMesh, 1.08);
    this.hips.add(hipsMesh);

    for (const [side, leg] of [[-1, this.legL], [1, this.legR]] as Array<[number, THREE.Group]>) {
      leg.position.set(0.12 * side, -0.06, 0);
      const limb = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.5, 0.11), darkMat);
      limb.position.y = -0.27;
      leg.add(limb);
      const foot = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.2), darkMat);
      foot.position.set(0, -0.52, -0.04);
      leg.add(foot);
      this.hips.add(leg);
    }

    // Torso
    this.torso.position.y = 0.2;
    this.hips.add(this.torso);
    const chest = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.28, 0.5, 8), this.armorMat);
    chest.position.y = 0.24;
    chest.castShadow = true;
    attachOutline(chest, 1.07);
    this.torso.add(chest);

    // Neck
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.12, 8), darkMat);
    neck.position.y = 0.52;
    this.torso.add(neck);

    // Head
    this.head.position.y = 0.6;
    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 8), this.metalMat);
    helmet.position.y = 0.1;
    helmet.castShadow = true;
    attachOutline(helmet, 1.09);
    this.head.add(helmet);
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.055, 0.03), visorMat);
    visor.position.set(0, 0.1, -0.17);
    this.head.add(visor);
    this.torso.add(this.head);

    // Arms: wide enough to clear the chest outline; charcoal sleeves,
    // metal pauldrons + gauntlets so they read against any armor tint.
    for (const [side, arm] of [[-1, this.armL], [1, this.armR]] as Array<[number, THREE.Group]>) {
      arm.position.set(0.34 * side, 0.42, 0);
      const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), this.metalMat);
      arm.add(shoulder);
      const limb = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.38, 0.1), darkMat);
      limb.position.y = -0.21;
      arm.add(limb);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 6), this.metalMat);
      hand.position.y = -0.42;
      arm.add(hand);
      this.torso.add(arm);
    }

    this.weaponSocket.position.set(0, -0.44, 0);
    this.armR.add(this.weaponSocket);

    // Cape: the original design — wide red plane hanging from the shoulder
    // line, swaying with motion. z = 0.34 keeps it clear of the chest
    // outline hull (the old 0.19 sat inside the body).
    this.cape = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.80, 1, 4), clothMat);
    this.cape.position.set(0, 0.14, 0.34);
    this.cape.rotation.x = -0.18;
    this.cape.castShadow = true;
    this.torso.add(this.cape);
  }

  setArmorTint(color: number): void {
    this.armorMat.color.set(color);
  }

  /** Procedural pose blending. Priority: dead > hurt > dodge/rush > attack > cast > move > idle. */
  update(dt: number, s: RigState): void {
    const smooth = 1 - Math.exp(-18 * dt);

    // Targets. NOTE z-signs: negative z on the LEFT arm leans its bottom outward (-x).
    let rootX = 0;
    let rootSpin = 0;
    let torsoX = 0;
    let torsoY = 0;
    let headX = 0;
    let armLX = 0;
    let armRX = 0;
    let armLZ = -0.15;
    let armRZ = 0.15;
    let legLX = 0;
    let legRX = 0;
    let hipY = 0.78;

    if (s.moving) {
      this.walkPhase += dt * (7 + 5 * s.move01);
      const sw = Math.sin(this.walkPhase);
      const bob = Math.abs(Math.cos(this.walkPhase));
      legLX = sw * 0.75 * s.move01;
      legRX = -sw * 0.75 * s.move01;
      armLX = -sw * 0.55 * s.move01;
      armRX = sw * 0.55 * s.move01;
      torsoY = sw * 0.09 * s.move01;
      torsoX = 0.12 * s.move01;
      hipY = 0.78 - bob * 0.05 * s.move01;
    } else {
      const breathe = Math.sin(s.age * 2.2);
      armLX = breathe * 0.04;
      armRX = -breathe * 0.04;
      headX = Math.sin(s.age * 0.7) * 0.06;
      hipY = 0.78 + breathe * 0.012;
    }

    if (s.attackT >= 0) {
      const t = s.attackT;
      const wind = t < 0.35 ? t / 0.35 : 1;
      const swing = t < 0.35 ? 0 : Math.min(1, (t - 0.35) / 0.3);
      armRX = -2.3 * wind + 3.3 * swing;
      armRZ = 0.35 * wind + 0.1 * swing;
      torsoY = -0.45 * wind + 0.95 * swing;
      torsoX = 0.15;
      armLX = 0.6 * wind - 0.3 * swing;
    } else if (s.castT >= 0) {
      if (s.castKind === 'whirl') {
        rootSpin = 16;
        armLX = -1.4;
        armRX = -1.4;
        armLZ = -0.9;
        armRZ = 0.9;
      } else {
        armLX = -2.6;
        armRX = -2.6;
        headX = -0.25;
      }
    }

    if (s.dodgeT >= 0 || s.rushT >= 0) {
      torsoX = 0.55;
      armLX = 0.9;
      armRX = 0.9;
      legLX = 0.7;
      legRX = -0.4;
      if (s.dodgeT >= 0) rootSpin = 18;
    }

    if (s.hurtT >= 0 && s.hurtT < 1) {
      torsoX = -0.45;
      headX = -0.3;
      armLX = -0.7;
      armRX = -0.7;
    }

    if (s.deadT >= 0) {
      const t = Math.min(1, s.deadT);
      rootX = -t * (Math.PI / 2) * 0.92;
      hipY = 0.78 - t * 0.5;
      armLZ = -0.9;
      armRZ = 0.9;
      armLX = -0.4;
      armRX = -0.4;
    }

    // Apply with smoothing
    const l = (cur: number, target: number): number => cur + (target - cur) * smooth;
    this.root.rotation.x = l(this.root.rotation.x, rootX);
    if (rootSpin !== 0) this.root.rotation.y += rootSpin * dt;
    else if (!s.moving) this.root.rotation.y = l(this.root.rotation.y, 0);
    this.hips.position.y = l(this.hips.position.y, hipY);
    this.torso.rotation.x = l(this.torso.rotation.x, torsoX);
    this.torso.rotation.y = l(this.torso.rotation.y, torsoY);
    this.head.rotation.x = l(this.head.rotation.x, headX);
    this.armL.rotation.x = l(this.armL.rotation.x, armLX);
    this.armR.rotation.x = l(this.armR.rotation.x, armRX);
    this.armL.rotation.z = l(this.armL.rotation.z, armLZ);
    this.armR.rotation.z = l(this.armR.rotation.z, armRZ);
    this.legL.rotation.x = l(this.legL.rotation.x, legLX);
    this.legR.rotation.x = l(this.legR.rotation.x, legRX);

    // Cape: top tucked inward against the back, hem flowing outward.
    // Running streams it backward; flutter keeps it alive at idle.
    const flutter = Math.sin(s.age * 3.1) * 0.02;
    const flow = s.moving ? 0.1 * s.move01 : 0;
    this.cape.rotation.x = l(this.cape.rotation.x, -0.30 - flow - torsoX * 0.15 + flutter);
  }
}