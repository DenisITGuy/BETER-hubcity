import * as THREE from 'three';
import { Portal } from './Portal';
import { CircleCollider } from './Collider';
import { makeGlow } from './Fx';

interface Lantern {
  head: THREE.MeshStandardMaterial;
  glow: THREE.Sprite;
  phase: number;
}

export class Hub implements CircleCollider {
  readonly group = new THREE.Group();
  readonly portal = new Portal(0x4488ff, true);
  readonly spawn = new THREE.Vector3(0, 0, 4);

  private readonly solids: Array<{ minX: number; maxX: number; minZ: number; maxZ: number }> = [];
  private readonly roundSolids: Array<{ x: number; z: number; r: number }> = [];
  private readonly lanterns: Lantern[] = [];
  private time = 0;

  constructor() {
    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(45, 48),
      new THREE.MeshStandardMaterial({ color: 0x47703f, roughness: 1 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.group.add(ground);

    const plaza = new THREE.Mesh(
      new THREE.CylinderGeometry(11, 11, 0.12, 40),
      new THREE.MeshStandardMaterial({ color: 0x767b88, roughness: 0.95 }),
    );
    plaza.position.y = 0.06;
    plaza.receiveShadow = true;
    this.group.add(plaza);

    const fountain = new THREE.Mesh(
      new THREE.CylinderGeometry(1.6, 1.9, 0.7, 20),
      new THREE.MeshStandardMaterial({ color: 0x8a8f9c, roughness: 0.9 }),
    );
    fountain.position.set(0, 0.35, 0);
    fountain.castShadow = true;
    this.group.add(fountain);
    this.roundSolids.push({ x: 0, z: 0, r: 1.9 });

    const water = new THREE.Mesh(
      new THREE.CylinderGeometry(1.35, 1.35, 0.1, 20),
      new THREE.MeshStandardMaterial({ color: 0x3f8fd0, roughness: 0.15, metalness: 0.2 }),
    );
    water.position.set(0, 0.62, 0);
    this.group.add(water);

    const buildings: Array<[number, number, number, number, number]> = [
      [20, 20, 8, 6, 7],
      [70, 22, 6, 9, 6],
      [120, 20, 9, 5, 8],
      [160, 23, 7, 7, 7],
      [210, 21, 8, 6, 6],
      [260, 22, 6, 8, 9],
      [310, 20, 9, 6, 7],
      [350, 24, 6, 5, 6],
    ];
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xa8987f, roughness: 0.95 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x8a4a3a, roughness: 0.9 });
    for (const [angleDeg, dist, w, h, d] of buildings) {
      const a = (angleDeg * Math.PI) / 180;
      const x = Math.cos(a) * dist;
      const z = Math.sin(a) * dist;

      const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
      body.position.set(x, h / 2, z);
      body.castShadow = true;
      body.receiveShadow = true;
      this.group.add(body);
      this.solids.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });

      const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.72, 2.2, 4), roofMat);
      roof.position.set(x, h + 1.1, z);
      roof.rotation.y = Math.PI / 4;
      roof.castShadow = true;
      this.group.add(roof);
    }

    this.buildTrees();
    this.buildLanterns();
    this.buildWardStones();

    this.portal.object.position.set(0, 0, -8);
    this.group.add(this.portal.object);
  }

  /** Slow lantern flicker. Called by World while in hub. */
  update(dt: number): void {
    this.time += dt;
    for (const l of this.lanterns) {
      const f = Math.sin(this.time * 3 + l.phase) * 0.12 + Math.sin(this.time * 7.3 + l.phase * 2) * 0.06;
      l.head.emissiveIntensity = 1.5 + f;
      (l.glow.material as THREE.SpriteMaterial).opacity = 0.5 + f * 0.3;
    }
  }

  private buildTrees(): void {
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6b4a2f, roughness: 1 });
    const leafA = new THREE.MeshStandardMaterial({ color: 0x3f7a44, roughness: 1 });
    const leafB = new THREE.MeshStandardMaterial({ color: 0x4c8f50, roughness: 1 });

    for (let i = 0; i < 14; i++) {
      const angleDeg = i * (360 / 14) + (i % 3) * 7;
      // Keep the portal corridor (north, ~270°) clear.
      if (angleDeg > 245 && angleDeg < 295) continue;
      const a = (angleDeg * Math.PI) / 180;
      const dist = 15 + (i % 4) * 1.6;
      const x = Math.cos(a) * dist;
      const z = Math.sin(a) * dist;
      const s = 0.85 + (i % 3) * 0.18;

      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.12 * s, 0.2 * s, 1.3 * s, 7), trunkMat);
      trunk.position.set(x, 0.65 * s, z);
      trunk.castShadow = true;
      this.group.add(trunk);

      const c1 = new THREE.Mesh(new THREE.ConeGeometry(1.15 * s, 2.3 * s, 7), leafA);
      c1.position.set(x, 2.1 * s, z);
      c1.castShadow = true;
      this.group.add(c1);

      const c2 = new THREE.Mesh(new THREE.ConeGeometry(0.8 * s, 1.6 * s, 7), leafB);
      c2.position.set(x, 3.1 * s, z);
      c2.castShadow = true;
      this.group.add(c2);

      this.roundSolids.push({ x, z, r: 0.35 * s });
    }
  }

  private buildLanterns(): void {
    const postMat = new THREE.MeshStandardMaterial({ color: 0x2c3038, roughness: 0.7, metalness: 0.5 });
    for (const angleDeg of [45, 135, 225, 315]) {
      const a = (angleDeg * Math.PI) / 180;
      const x = Math.cos(a) * 10.4;
      const z = Math.sin(a) * 10.4;

      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.09, 2.1, 8), postMat);
      post.position.set(x, 1.05, z);
      post.castShadow = true;
      this.group.add(post);

      const headMat = new THREE.MeshStandardMaterial({ color: 0x332211, emissive: 0xffbb66, emissiveIntensity: 1.5 });
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.3, 0.24), headMat);
      head.position.set(x, 2.2, z);
      this.group.add(head);

      const glow = makeGlow(0xffbb66, 1.8);
      glow.position.set(x, 2.2, z);
      this.group.add(glow);

      this.lanterns.push({ head: headMat, glow, phase: angleDeg });
      this.roundSolids.push({ x, z, r: 0.15 });
    }
  }

/** Three ward stones ringing the plaza: visit-quest anchors (ZONES data). */
  private buildWardStones(): void {
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x6b7280, roughness: 0.9, flatShading: true });
    const runeMat = new THREE.MeshStandardMaterial({ color: 0x113355, emissive: 0x66bbff, emissiveIntensity: 1.6 });
    const spots: Array<[number, number]> = [
      [0, -10.2],
      [0, 10.2],
      [-10.2, 0],
    ];
    for (const [x, z] of spots) {
      const g = new THREE.Group();
      g.position.set(x, 0, z);
      g.rotation.y = Math.atan2(x, z); // face the plaza center

      const stone = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.4, 0.35), stoneMat);
      stone.position.y = 0.7;
      stone.castShadow = true;
      g.add(stone);

      const rune = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.8, 0.06), runeMat);
      rune.position.set(0, 0.8, -0.19);
      g.add(rune);

      const glow = makeGlow(0x66bbff, 1.6);
      glow.position.y = 0.9;
      g.add(glow);

      this.group.add(g);
      this.roundSolids.push({ x, z, r: 0.45 });
    }
  }

  collideCircle(pos: THREE.Vector3, radius: number): void {
    for (const s of this.solids) {
      const nx = THREE.MathUtils.clamp(pos.x, s.minX, s.maxX);
      const nz = THREE.MathUtils.clamp(pos.z, s.minZ, s.maxZ);
      const dx = pos.x - nx;
      const dz = pos.z - nz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= radius * radius) continue;
      if (d2 < 1e-8) {
        const left = pos.x - s.minX;
        const right = s.maxX - pos.x;
        const up = pos.z - s.minZ;
        const down = s.maxZ - pos.z;
        const m = Math.min(left, right, up, down);
        if (m === left) pos.x = s.minX - radius;
        else if (m === right) pos.x = s.maxX + radius;
        else if (m === up) pos.z = s.minZ - radius;
        else pos.z = s.maxZ - radius;
        continue;
      }
      const d = Math.sqrt(d2);
      const push = (radius - d) / d;
      pos.x += dx * push;
      pos.z += dz * push;
    }

    for (const c of this.roundSolids) {
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      const d = Math.hypot(dx, dz);
      const min = c.r + radius;
      if (d >= min || d < 1e-6) continue;
      const push = (min - d) / d;
      pos.x += dx * push;
      pos.z += dz * push;
    }

    const dist = Math.hypot(pos.x, pos.z);
    const max = 43;
    if (dist > max) {
      pos.x *= max / dist;
      pos.z *= max / dist;
    }
  }
}