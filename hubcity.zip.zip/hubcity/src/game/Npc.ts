import * as THREE from 'three';
import { NpcDefinition } from './data/npcs';
import { attachOutline } from './Fx';

/**
 * Simple villager rig: robe cone, head, hood/hat per palette.
 * Idle bob + turns to face the player when approached. Blocks movement
 * via circle push-out handled by World.
 */
export class Npc {
  readonly object = new THREE.Group();
  readonly def: NpcDefinition;
  readonly radius = 0.35;

  private readonly head: THREE.Group;
  private age = Math.random() * 10;

  constructor(def: NpcDefinition) {
    this.def = def;
    this.object.position.set(def.position.x, 0, def.position.z);
    this.object.rotation.y = def.facingYaw;

    const robeMat = new THREE.MeshStandardMaterial({ color: def.palette.robe, roughness: 0.9, flatShading: true });
    const hoodMat = new THREE.MeshStandardMaterial({ color: def.palette.hood, roughness: 0.9, flatShading: true });
    const skinMat = new THREE.MeshStandardMaterial({ color: def.palette.skin, roughness: 0.8, flatShading: true });
    const accentMat = new THREE.MeshStandardMaterial({
      color: def.palette.accent, emissive: def.palette.accent, emissiveIntensity: 0.35,
    });

    const robe = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.15, 8), robeMat);
    robe.position.y = 0.575;
    robe.castShadow = true;
    attachOutline(robe, 1.06);
    this.object.add(robe);

    const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.32, 0.1, 8), accentMat);
    belt.position.y = 0.75;
    this.object.add(belt);

    this.head = new THREE.Group();
    this.head.position.y = 1.32;
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8), skinMat);
    skull.castShadow = true;
    attachOutline(skull, 1.08);
    this.head.add(skull);

    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x141422 });
    const eyeGeo = new THREE.SphereGeometry(0.03, 6, 6);
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.06, 0.02, -0.15);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.06, 0.02, -0.15);
    this.head.add(eyeL, eyeR);

    if (def.hatStyle === 'hood') {
      const hood = new THREE.Mesh(
        new THREE.SphereGeometry(0.2, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.62),
        hoodMat,
      );
      hood.position.y = 0.02;
      hood.rotation.x = -0.25;
      this.head.add(hood);
    } else if (def.hatStyle === 'hat') {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.03, 10), hoodMat);
      brim.position.y = 0.12;
      this.head.add(brim);
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.14, 10), hoodMat);
      top.position.y = 0.2;
      this.head.add(top);
    }
    this.object.add(this.head);
  }

  update(dt: number, playerPos: THREE.Vector3): void {
    this.age += dt;
    this.object.position.y = Math.sin(this.age * 1.6) * 0.02;

    const dx = playerPos.x - this.object.position.x;
    const dz = playerPos.z - this.object.position.z;
    const dist = Math.hypot(dx, dz);

    const target = dist < 3.2 ? Math.atan2(-dx, -dz) : this.def.facingYaw;
    const rate = dist < 3.2 ? 4 : 1.5;
    let d = (target - this.object.rotation.y) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    this.object.rotation.y += d * (1 - Math.exp(-rate * dt));
  }
}