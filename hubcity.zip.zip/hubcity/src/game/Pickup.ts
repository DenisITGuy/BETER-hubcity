import * as THREE from 'three';
import { WORLD } from './data/tunables';
import { ItemDefinition } from './data/schemas';
import { RARITY_HEX } from '../game/items';
import { makeGlow } from './Fx';

export class Pickup {
  readonly object = new THREE.Group();
  private readonly spin: THREE.Mesh;
  private age = 0;

  constructor(
    position: THREE.Vector3,
    public readonly gold: number,
    public readonly item: ItemDefinition | null,
  ) {
    const color = item ? RARITY_HEX[item.rarity] : 0xffd166;

    if (item) {
      this.spin = new THREE.Mesh(
        new THREE.BoxGeometry(0.3, 0.3, 0.3),
        new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.45, roughness: 0.35 }),
      );
    } else {
      this.spin = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.22),
        new THREE.MeshStandardMaterial({ color, emissive: 0x553300, roughness: 0.3, metalness: 0.6 }),
      );
    }
    this.spin.position.y = 0.55;
    this.spin.castShadow = true;
    this.object.add(this.spin);

    // Light beam + ground glow so loot reads from across the room.
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.1, 2.4, 6, 1, true),
      new THREE.MeshBasicMaterial({
        color, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false,
      }),
    );
    beam.position.y = 1.2;
    this.object.add(beam);

    const glow = makeGlow(color, 1.4);
    glow.position.y = 0.55;
    this.object.add(glow);

    this.object.position.copy(position);
  }

  update(dt: number, playerPos: THREE.Vector3): boolean {
    this.age += dt;
    this.spin.rotation.y += dt * 3;
    this.spin.position.y = 0.55 + Math.sin(this.age * 3) * 0.1;
    return this.object.position.distanceTo(playerPos) < WORLD.pickupCollectRadius;
  }
}