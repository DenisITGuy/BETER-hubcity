import * as THREE from 'three';
import { Input } from '../engine/Input';
import { CircleCollider } from './Collider';
import { lerpAngle } from './math';
import { PLAYER, COMBAT } from './data/tunables';
import { AbilityDefinition, ItemDefinition, PlayerStats } from './data/schemas';
import { ITEMS } from '../game/items';
import { LEVEL_TABLE, MAX_LEVEL } from './data/leveling';
import { attachOutline } from './Fx';
import { CastKind, HeroRig, RigState } from './HeroRig';

export interface DerivedStats {
  maxHealth: number;
  meleeDamage: number;
  dodgeCooldown: number;
  abilityPower: number;
}

export interface EquipmentState {
  weapon: string | null;
  armor: string | null;
}

export class Player {
  readonly object = new THREE.Group();
  readonly radius = PLAYER.radius;
  readonly attackRange = COMBAT.attackRange;
  readonly rig = new HeroRig();

  // Progression
  level = 1;
  xp = 0;
  statPoints = 0;
  baseStats: PlayerStats = { strength: 0, vitality: 0, agility: 0, focus: 0 };
  derived: DerivedStats = { maxHealth: 100, meleeDamage: 12, dodgeCooldown: 0.9, abilityPower: 10 };

  // Gear
  inventory: ItemDefinition[] = [];
  equippedWeapon: ItemDefinition | null = null;
  equippedArmor: ItemDefinition | null = null;

  // Abilities
  readonly abilityCooldowns = [0, 0, 0];
  abilityFired = -1;
  rushImpact = false;

  // Combat state
  health = 100;
  gold = 0;
  attackFired = false;
  dodgeFired = false;
  readonly attackOrigin = new THREE.Vector3();
  readonly attackDir = new THREE.Vector3(0, 0, -1);
  hurtThisFrame = false;
  lastDamageTaken = 0;

  private attackCooldown = 0;
  private dodgeTime = 0;
  private dodgeCooldownTimer = 0;
  private readonly dodgeDir = new THREE.Vector3(0, 0, -1);
  private rushTime = 0;
  private rushSpeed = 0;
  private readonly rushDir = new THREE.Vector3(0, 0, -1);
  private invuln = 0;
  private facing = 0;
  private hitFlash = 0;
  private healFlash = 0;
  private swingTime = 0;
  private castTime = 0;
  private castKind: CastKind = 'none';
  private deadTime = -1;
  private age = 0;

  private readonly swingMat: THREE.MeshBasicMaterial;
  private readonly weaponMat: THREE.MeshStandardMaterial;
  private weaponMesh: THREE.Mesh | null = null;

  constructor() {
    this.object.add(this.rig.root);

    this.swingMat = new THREE.MeshBasicMaterial({
      color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false,
    });
    const swing = new THREE.Mesh(
      new THREE.CircleGeometry(this.attackRange, 20, Math.PI / 6, (Math.PI * 2) / 3),
      this.swingMat,
    );
    swing.rotation.x = -Math.PI / 2;
    swing.position.y = 0.12;
    this.object.add(swing);

    this.weaponMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.35, metalness: 0.6, flatShading: true });
  }

  get isDead(): boolean {
    return this.health <= 0;
  }

  get isRushing(): boolean {
    return this.rushTime > 0;
  }

  recalculateStats(): void {
    let maxHealth = 100 + this.baseStats.vitality * 10;
    let meleeDamage = COMBAT.attackDamage + this.baseStats.strength * 2;
    let dodgeCooldown = PLAYER.dodgeCooldown * (1 - this.baseStats.agility * 0.05);
    let abilityPower = 10 + this.baseStats.focus * 5;

    for (const item of [this.equippedWeapon, this.equippedArmor]) {
      if (!item) continue;
      maxHealth += item.stats.maxHealth ?? 0;
      meleeDamage += item.stats.meleeDamage ?? 0;
      dodgeCooldown += item.stats.dodgeCooldown ?? 0;
      abilityPower += item.stats.abilityPower ?? 0;
    }

    this.derived = {
      maxHealth,
      meleeDamage,
      dodgeCooldown: Math.max(0.15, dodgeCooldown),
      abilityPower,
    };
    if (this.health > this.derived.maxHealth) this.health = this.derived.maxHealth;
  }

  addXP(amount: number): boolean {
    if (this.level >= MAX_LEVEL) return false;
    this.xp += amount;
    let leveledUp = false;
    while (this.level < MAX_LEVEL) {
      const nextLevelReq = LEVEL_TABLE[this.level].xpRequired;
      if (this.xp >= nextLevelReq) {
        this.xp -= nextLevelReq;
        this.level++;
        this.statPoints += LEVEL_TABLE[this.level - 1].statPointsAwarded;
        leveledUp = true;
        this.recalculateStats();
        this.health = this.derived.maxHealth;
      } else {
        break;
      }
    }
    return leveledUp;
  }

  allocateStat(stat: keyof PlayerStats): boolean {
    if (this.statPoints <= 0) return false;
    this.baseStats[stat]++;
    this.statPoints--;
    this.recalculateStats();
    return true;
  }

  addItem(def: ItemDefinition): void {
    this.inventory.push(def);
  }

  equip(itemId: string): boolean {
    const idx = this.inventory.findIndex((i) => i.id === itemId);
    if (idx === -1) return false;
    const item = this.inventory[idx];
    this.inventory.splice(idx, 1);
    if (item.slot === 'weapon') {
      if (this.equippedWeapon) this.inventory.push(this.equippedWeapon);
      this.equippedWeapon = item;
    } else {
      if (this.equippedArmor) this.inventory.push(this.equippedArmor);
      this.equippedArmor = item;
    }
    this.recalculateStats();
    this.refreshVisuals();
    return true;
  }

  heal(amount: number): void {
    this.health = Math.min(this.derived.maxHealth, this.health + amount);
    this.healFlash = 0.45;
  }

  tryAbility(index: number, def: AbilityDefinition): boolean {
    if (this.isDead || this.dodgeTime > 0 || this.rushTime > 0) return false;
    if (this.level < def.unlockLevel) return false;
    if (this.abilityCooldowns[index] > 0) return false;

    this.abilityCooldowns[index] = def.cooldown;
    this.abilityFired = index;

    if (def.id === 'rush') {
      this.rushTime = def.params.duration;
      this.rushSpeed = def.params.distance / def.params.duration;
      this.rushDir.set(-Math.sin(this.facing), 0, -Math.cos(this.facing));
    } else {
      this.castTime = 0.4;
      this.castKind = def.id === 'whirl' ? 'whirl' : 'mend';
    }
    return true;
  }

  loadProgression(
    level: number,
    xp: number,
    statPoints: number,
    stats: PlayerStats,
    inventoryIds: string[],
    equipment: EquipmentState,
  ): void {
    this.level = level;
    this.xp = xp;
    this.statPoints = statPoints;
    this.baseStats = { ...stats };
    this.inventory = inventoryIds.map((id) => ITEMS[id]).filter((d): d is ItemDefinition => Boolean(d));
    this.equippedWeapon = equipment.weapon ? ITEMS[equipment.weapon] ?? null : null;
    this.equippedArmor = equipment.armor ? ITEMS[equipment.armor] ?? null : null;
    this.recalculateStats();
    this.refreshVisuals();
    this.health = this.derived.maxHealth;
  }

  refreshVisuals(): void {
    if (this.equippedWeapon) {
      if (!this.weaponMesh) {
        this.weaponMesh = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.95, 0.12), this.weaponMat);
        attachOutline(this.weaponMesh, 1.15);
        this.weaponMesh.rotation.x = -Math.PI / 2;
        this.weaponMesh.position.set(0, 0, -0.35);
        this.rig.weaponSocket.add(this.weaponMesh);
      }
      this.weaponMat.color.set(this.equippedWeapon.visualColor);
      this.weaponMesh.visible = true;
    } else if (this.weaponMesh) {
      this.weaponMesh.visible = false;
    }

    this.rig.setArmorTint(this.equippedArmor ? this.equippedArmor.visualColor : 0x3fa7ff);
  }

  reset(position: THREE.Vector3): void {
    this.object.position.copy(position);
    this.health = this.derived.maxHealth;
    this.attackCooldown = 0;
    this.dodgeTime = 0;
    this.dodgeCooldownTimer = 0;
    this.rushTime = 0;
    this.castTime = 0;
    this.deadTime = -1;
    this.abilityCooldowns[0] = 0;
    this.abilityCooldowns[1] = 0;
    this.abilityCooldowns[2] = 0;
    this.invuln = 0;
    this.facing = 0;
    this.object.rotation.y = 0;
    this.rig.root.rotation.x = 0;
    this.rig.root.rotation.y = 0;
  }

  takeDamage(amount: number): boolean {
    if (this.invuln > 0 || this.isDead) return false;
    this.health = Math.max(0, this.health - amount);
    this.lastDamageTaken = amount;
    this.invuln = PLAYER.hurtIFrames;
    this.hitFlash = PLAYER.hurtFlashTime;
    this.hurtThisFrame = true;
    return true;
  }

  /** Death-fall animation only; called by World while dead. */
  updateDeath(dt: number): void {
    if (this.deadTime < 0) this.deadTime = 0;
    this.deadTime += dt;
    const state: RigState = {
      age: this.age, moving: false, move01: 0,
      attackT: -1, dodgeT: -1, rushT: -1, hurtT: -1,
      deadT: Math.min(1, this.deadTime / 0.7),
      castT: -1, castKind: 'none',
    };
    this.rig.update(dt, state);
  }

  update(dt: number, input: Input, cameraYaw: number, collider: CircleCollider): void {
    this.hurtThisFrame = false;
    this.attackFired = false;
    this.dodgeFired = false;
    // NOTE: abilityFired is intentionally NOT cleared here.
    // World reads it in resolveAbilityEvents() and clears it there.
    this.age += dt;
    this.castTime = Math.max(0, this.castTime - dt);

    for (let i = 0; i < this.abilityCooldowns.length; i++) {
      this.abilityCooldowns[i] = Math.max(0, this.abilityCooldowns[i] - dt);
    }
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.dodgeCooldownTimer = Math.max(0, this.dodgeCooldownTimer - dt);
    this.invuln = Math.max(0, this.invuln - dt);

    const forward = new THREE.Vector3(-Math.sin(cameraYaw), 0, -Math.cos(cameraYaw));
    const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0));

    const move = new THREE.Vector3();
    if (input.isHeld('KeyW')) move.add(forward);
    if (input.isHeld('KeyS')) move.sub(forward);
    if (input.isHeld('KeyD')) move.add(right);
    if (input.isHeld('KeyA')) move.sub(right);

    const moving = move.lengthSq() > 1e-4;
    if (moving) move.normalize();

    if (input.wasPressed('ShiftLeft') && this.dodgeCooldownTimer <= 0 && this.dodgeTime <= 0 && this.rushTime <= 0) {
      this.dodgeTime = PLAYER.dodgeTime;
      this.dodgeCooldownTimer = this.derived.dodgeCooldown;
      this.invuln = Math.max(this.invuln, PLAYER.dodgeIFrames);
      this.dodgeDir.copy(moving ? move : forward);
      this.dodgeFired = true;
    }

    const pos = this.object.position;
    let speed01 = 0;
    if (this.rushTime > 0) {
      this.rushTime -= dt;
      const step = this.rushSpeed * dt;
      pos.x += this.rushDir.x * step;
      collider.collideCircle(pos, this.radius);
      pos.z += this.rushDir.z * step;
      collider.collideCircle(pos, this.radius);
      if (this.rushTime <= 0) this.rushImpact = true;
      speed01 = 1;
    } else if (this.dodgeTime > 0) {
      this.dodgeTime -= dt;
      const step = PLAYER.dodgeSpeed * dt;
      pos.x += this.dodgeDir.x * step;
      collider.collideCircle(pos, this.radius);
      pos.z += this.dodgeDir.z * step;
      collider.collideCircle(pos, this.radius);
      speed01 = 1;
    } else if (moving) {
      const step = PLAYER.moveSpeed * dt;
      pos.x += move.x * step;
      collider.collideCircle(pos, this.radius);
      pos.z += move.z * step;
      collider.collideCircle(pos, this.radius);
      speed01 = 0.7;

      const targetYaw = Math.atan2(-move.x, -move.z);
      this.facing = lerpAngle(this.facing, targetYaw, 1 - Math.exp(-PLAYER.turnSmoothing * dt));
      this.object.rotation.y = this.facing;
    }

    const wantsAttack = input.wasPressed('Space') || input.wasPressed('Mouse0');
    if (wantsAttack && this.attackCooldown <= 0 && this.dodgeTime <= 0 && this.rushTime <= 0) {
      this.attackCooldown = COMBAT.attackCooldown;
      this.attackFired = true;
      this.attackOrigin.copy(pos);
      this.attackDir.set(-Math.sin(this.facing), 0, -Math.cos(this.facing));
      this.swingTime = COMBAT.swingTime;
    }

    let attackT = -1;
    if (this.swingTime > 0) {
      attackT = 1 - this.swingTime / COMBAT.swingTime;
      this.swingTime -= dt;
      this.swingMat.opacity = Math.max(0, this.swingTime / COMBAT.swingTime) * COMBAT.swingOpacity;
    } else {
      this.swingMat.opacity = 0;
    }

    let er = 0;
    let eg = 0;
    if (this.hitFlash > 0) {
      this.hitFlash -= dt;
      er = Math.max(0, this.hitFlash) * PLAYER.hurtFlashIntensity;
    }
    if (this.healFlash > 0) {
      this.healFlash -= dt;
      eg = Math.max(0, this.healFlash) * 2;
    }
    this.rig.root.traverse((o) => {
      if (o instanceof THREE.Mesh && o.material instanceof THREE.MeshStandardMaterial && o.material.flatShading) {
        o.material.emissive.setRGB(er, eg, 0);
      }
    });

    const state: RigState = {
      age: this.age,
      moving: moving || this.dodgeTime > 0 || this.rushTime > 0,
      move01: speed01,
      attackT,
      dodgeT: this.dodgeTime > 0 ? 1 - this.dodgeTime / PLAYER.dodgeTime : -1,
      rushT: this.rushTime > 0 ? 1 - this.rushTime / 0.18 : -1,
      hurtT: this.hitFlash > 0 ? 1 - this.hitFlash / PLAYER.hurtFlashTime : -1,
      deadT: -1,
      castT: this.castTime > 0 ? 1 - this.castTime / 0.4 : -1,
      castKind: this.castKind,
    };
    this.rig.update(dt, state);
  }
}