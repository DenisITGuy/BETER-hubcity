import * as THREE from 'three';
import { WORLD } from './data/tunables';

/** Ground pad + spinning ring. Glow = active; World does trigger checks. */
export class Portal {
  readonly object = new THREE.Group();
  active: boolean;

  private readonly ringMat: THREE.MeshStandardMaterial;
  private readonly ring: THREE.Mesh;
  private readonly activeColor: THREE.Color;
  private readonly idleColor = new THREE.Color(0x333844);
  private time = 0;

  constructor(color: number, activeFromStart = false) {
    this.active = activeFromStart;
    this.activeColor = new THREE.Color(color);

    const padMat = new THREE.MeshStandardMaterial({ color: 0x22262f, roughness: 0.8 });
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.5, 0.15, 24), padMat);
    pad.position.y = 0.075;
    pad.receiveShadow = true;
    this.object.add(pad);

    this.ringMat = new THREE.MeshStandardMaterial({
      color: 0x111318,
      emissive: this.idleColor.clone(),
      emissiveIntensity: 0.5,
      roughness: 0.4,
    });
    this.ring = new THREE.Mesh(new THREE.TorusGeometry(1.05, 0.1, 10, 32), this.ringMat);
    this.ring.position.y = 1.25;
    this.ring.castShadow = true;
    this.object.add(this.ring);
  }

  setActive(active: boolean): void {
    this.active = active;
  }

  contains(pos: THREE.Vector3, radius: number = WORLD.portalTriggerRadius): boolean {
    const dx = pos.x - this.object.position.x;
    const dz = pos.z - this.object.position.z;
    return dx * dx + dz * dz < radius * radius;
  }

  update(dt: number): void {
    this.time += dt;
    const target = this.active ? this.activeColor : this.idleColor;
    this.ringMat.emissive.lerp(target, 1 - Math.exp(-6 * dt));
    this.ringMat.emissiveIntensity = this.active ? 1.4 + Math.sin(this.time * 4) * 0.4 : 0.5;
    this.ring.rotation.z += dt * (this.active ? 1.6 : 0.3);
  }
}