import * as THREE from 'three';
import { DungeonMesh } from './DungeonMesh';
import { Player } from './Player';

interface Shot {
  mesh: THREE.Mesh;
  mat: THREE.MeshStandardMaterial;
  vel: THREE.Vector3;
  life: number;
  damage: number;
  active: boolean;
}

const POOL = 24;
const SHOT_RADIUS = 0.22;

/** Fixed-size projectile pool. No allocations after construction. */
export class ProjectilePool {
  readonly group = new THREE.Group();
  private readonly shots: Shot[] = [];

  constructor() {
    const geo = new THREE.SphereGeometry(SHOT_RADIUS, 10, 8);
    for (let i = 0; i < POOL; i++) {
      const mat = new THREE.MeshStandardMaterial({ color: 0x220033, emissive: 0xb465ff, emissiveIntensity: 2.2 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.group.add(mesh);
      this.shots.push({ mesh, mat, vel: new THREE.Vector3(), life: 0, damage: 0, active: false });
    }
  }

  spawn(x: number, z: number, dirX: number, dirZ: number, speed: number, damage: number, color: number): void {
    for (const s of this.shots) {
      if (s.active) continue;
      s.active = true;
      s.life = 0;
      s.damage = damage;
      s.mesh.visible = true;
      s.mesh.position.set(x, 0.9, z);
      s.vel.set(dirX * speed, 0, dirZ * speed);
      s.mat.emissive.set(color);
      return;
    }
  }

  update(dt: number, dungeon: DungeonMesh, player: Player): void {
    for (const s of this.shots) {
      if (!s.active) continue;
      s.life += dt;
      if (s.life > 4) {
        this.kill(s);
        continue;
      }
      s.mesh.position.addScaledVector(s.vel, dt);
      s.mesh.rotation.y += dt * 10;

      const p = s.mesh.position;
      if (dungeon.isSolidWorld(p.x, p.z)) {
        this.kill(s);
        continue;
      }
      if (!player.isDead) {
        const dx = p.x - player.object.position.x;
        const dz = p.z - player.object.position.z;
        const rr = SHOT_RADIUS + player.radius;
        if (dx * dx + dz * dz < rr * rr) {
          player.takeDamage(s.damage);
          this.kill(s);
        }
      }
    }
  }

  clear(): void {
    for (const s of this.shots) this.kill(s);
  }

  private kill(s: Shot): void {
    s.active = false;
    s.mesh.visible = false;
  }
}