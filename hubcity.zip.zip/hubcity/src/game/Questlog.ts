import { QUESTS, QuestDefinition, QuestObjective } from './data/quests';

export type QuestState = 'active' | 'complete' | 'turnedin';

export interface QuestProgress {
  state: QuestState;
  counts: number[];
}

export interface QuestContext {
  level: number;
  depth: number;
  flags: Set<string>;
  turnedIn: (questId: string) => boolean;
}

export interface QuestEvents {
  toast(text: string, ms?: number, color?: string): void;
  grantRewards(def: QuestDefinition): void;
}

export interface QuestPanelEntry {
  title: string;
  state: QuestState;
  description: string;
  lines: string[];
}

export interface QuestSaveEntry {
  s: number;
  c: number[];
}

const STATE_INDEX: Record<QuestState, number> = { active: 0, complete: 1, turnedin: 2 };
const INDEX_STATE: QuestState[] = ['active', 'complete', 'turnedin'];

/**
 * Quest state machine: available (not started + prereqs met) → active →
 * complete → turnedin. Fed by World events (kill / collect / zone enter).
 */
export class QuestLog {
  private readonly progress = new Map<string, QuestProgress>();
  private readonly events: QuestEvents;

  constructor(events: QuestEvents) {
    this.events = events;
  }

  getState(questId: string): QuestState | null {
    return this.progress.get(questId)?.state ?? null;
  }
  isActive(questId: string): boolean {
    return this.getState(questId) === 'active';
  }
  isComplete(questId: string): boolean {
    return this.getState(questId) === 'complete';
  }
  isTurnedIn(questId: string): boolean {
    return this.getState(questId) === 'turnedin';
  }

  canAccept(questId: string, ctx: QuestContext): boolean {
    if (this.getState(questId) !== null) return false;
    const def = QUESTS[questId];
    if (!def) return false;
    for (const p of def.prereqs) {
      if (p.level !== undefined && ctx.level < p.level) return false;
      if (p.depth !== undefined && ctx.depth < p.depth) return false;
      if (p.questId !== undefined && !ctx.turnedIn(p.questId)) return false;
      if (p.flag !== undefined && !ctx.flags.has(p.flag)) return false;
    }
    return true;
  }

  /** Seeds collect objectives from what the player already carries. */
  accept(questId: string, inventoryIds: string[]): boolean {
    const def = QUESTS[questId];
    if (!def || this.getState(questId) !== null) return false;
    const counts = def.objectives.map((o) => {
      if (o.type === 'collect') {
        let have = 0;
        for (const id of inventoryIds) if (id === o.itemId) have++;
        return Math.min(have, o.count);
      }
      return 0;
    });
    const prog: QuestProgress = { state: 'active', counts };
    this.progress.set(questId, prog);
    this.events.toast(`Quest accepted: ${def.title}`, 2600, '#66bbff');
    this.checkComplete(def, prog);
    return true;
  }

  turnIn(questId: string): boolean {
    const def = QUESTS[questId];
    const prog = this.progress.get(questId);
    if (!def || !prog || prog.state !== 'complete') return false;
    prog.state = 'turnedin';
    this.events.grantRewards(def);
    this.events.toast(`Rewards granted: ${def.title}`, 3200, '#ffd166');
    return true;
  }

  onEnemyKill(enemyId: string): void {
    for (const [id, prog] of this.progress) {
      if (prog.state !== 'active') continue;
      const def = QUESTS[id];
      def.objectives.forEach((o, i) => {
        if (o.type === 'kill' && o.enemyId === enemyId && prog.counts[i] < o.count) {
          prog.counts[i]++;
          this.progressToast(def, o, prog.counts[i]);
          this.checkComplete(def, prog);
        }
      });
    }
  }

  onCollect(itemId: string): void {
    for (const [id, prog] of this.progress) {
      if (prog.state !== 'active') continue;
      const def = QUESTS[id];
      def.objectives.forEach((o, i) => {
        if (o.type === 'collect' && o.itemId === itemId && prog.counts[i] < o.count) {
          prog.counts[i]++;
          this.progressToast(def, o, prog.counts[i]);
          this.checkComplete(def, prog);
        }
      });
    }
  }

  onZoneEnter(zoneId: string): void {
    for (const [id, prog] of this.progress) {
      if (prog.state !== 'active') continue;
      const def = QUESTS[id];
      def.objectives.forEach((o, i) => {
        if (o.type === 'visit' && o.zoneId === zoneId && prog.counts[i] < 1) {
          prog.counts[i] = 1;
          this.events.toast(`${def.title}: ward stone inspected`, 2200, '#66bbff');
          this.checkComplete(def, prog);
        }
      });
    }
  }

  private progressToast(def: QuestDefinition, o: QuestObjective, now: number): void {
    const label = o.type === 'kill' ? o.enemyId : o.type === 'collect' ? o.itemId : o.zoneId;
    const target = o.type === 'visit' ? 1 : o.count;
    this.events.toast(`${def.title}: ${label} ${now}/${target}`, 2000);
  }

  private checkComplete(def: QuestDefinition, prog: QuestProgress): void {
    if (prog.state !== 'active') return;
    const done = def.objectives.every((o, i) => prog.counts[i] >= (o.type === 'visit' ? 1 : o.count));
    if (done) {
      prog.state = 'complete';
      this.events.toast(`Objectives complete — return to the giver: ${def.title}`, 3200, '#7ed957');
    }
  }

  trackerLines(): string[] {
    const lines: string[] = [];
    for (const [id, prog] of this.progress) {
      if (prog.state !== 'active') continue;
      const def = QUESTS[id];
      lines.push(def.title);
      def.objectives.forEach((o, i) => {
        const target = o.type === 'visit' ? 1 : o.count;
        const label =
          o.type === 'kill' ? `Kill ${o.enemyId}` : o.type === 'collect' ? `Collect ${o.itemId}` : `Visit ${o.zoneId}`;
        const done = prog.counts[i] >= target;
        lines.push(`  ${label} ${prog.counts[i]}/${target}${done ? ' ✓' : ''}`);
      });
    }
    return lines;
  }

  panelView(): QuestPanelEntry[] {
    const entries: QuestPanelEntry[] = [];
    for (const def of Object.values(QUESTS)) {
      const prog = this.progress.get(def.id);
      if (!prog) continue;
      entries.push({
        title: def.title,
        state: prog.state,
        description: def.description,
        lines: def.objectives.map((o, i) => {
          const target = o.type === 'visit' ? 1 : o.count;
          const label =
            o.type === 'kill' ? `Kill ${o.enemyId}` : o.type === 'collect' ? `Collect ${o.itemId}` : `Visit ${o.zoneId}`;
          return `${label} — ${prog.counts[i]}/${target}`;
        }),
      });
    }
    return entries;
  }

  serialize(): Record<string, QuestSaveEntry> {
    const out: Record<string, QuestSaveEntry> = {};
    for (const [id, prog] of this.progress) {
      out[id] = { s: STATE_INDEX[prog.state], c: [...prog.counts] };
    }
    return out;
  }

  load(data: Record<string, QuestSaveEntry> | undefined): void {
    this.progress.clear();
    if (!data) return;
    for (const [id, entry] of Object.entries(data)) {
      if (!QUESTS[id]) continue;
      const state = INDEX_STATE[entry.s];
      if (!state) continue;
      this.progress.set(id, { state, counts: [...(entry.c ?? [])] });
    }
  }
}