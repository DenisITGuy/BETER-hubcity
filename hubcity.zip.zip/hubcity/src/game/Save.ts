import { PlayerStats } from './data/schemas';
import { QuestSaveEntry } from './Questlog';

export interface EquipmentSave {
  weapon: string | null;
  armor: string | null;
}

export interface SaveData {
  v: 3;
  gold: number;
  depth: number;
  level: number;
  xp: number;
  statPoints: number;
  stats: PlayerStats;
  inventory: string[];
  equipment: EquipmentSave;
  quests: Record<string, QuestSaveEntry>;
  flags: string[];
}

const KEY = 'hubcity.save';

const DEFAULT_STATS: PlayerStats = { strength: 0, vitality: 0, agility: 0, focus: 0 };

const DEFAULTS: SaveData = {
  v: 3,
  gold: 0,
  depth: 1,
  level: 1,
  xp: 0,
  statPoints: 0,
  stats: { ...DEFAULT_STATS },
  inventory: [],
  equipment: { weapon: null, armor: null },
  quests: {},
  flags: [],
};

/** Lossless migration from v1/v2: progression and gear carry over. */
export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS, stats: { ...DEFAULT_STATS }, inventory: [], quests: {}, flags: [] };

    const parsed = JSON.parse(raw) as any;

    const base: SaveData = {
      v: 3,
      gold: typeof parsed.gold === 'number' ? parsed.gold : 0,
      depth: Math.max(1, parsed.depth ?? 1),
      level: Math.max(1, parsed.level ?? 1),
      xp: Math.max(0, parsed.xp ?? 0),
      statPoints: Math.max(0, parsed.statPoints ?? 0),
      stats: {
        strength: parsed.stats?.strength ?? 0,
        vitality: parsed.stats?.vitality ?? 0,
        agility: parsed.stats?.agility ?? 0,
        focus: parsed.stats?.focus ?? 0,
      },
      inventory: Array.isArray(parsed.inventory)
        ? parsed.inventory.filter((x: unknown): x is string => typeof x === 'string')
        : [],
      equipment: {
        weapon: typeof parsed.equipment?.weapon === 'string' ? parsed.equipment.weapon : null,
        armor: typeof parsed.equipment?.armor === 'string' ? parsed.equipment.armor : null,
      },
      quests: parsed.quests && typeof parsed.quests === 'object' ? parsed.quests : {},
      flags: Array.isArray(parsed.flags)
        ? parsed.flags.filter((x: unknown): x is string => typeof x === 'string')
        : [],
    };
    return base;
  } catch {
    return { ...DEFAULTS, stats: { ...DEFAULT_STATS }, inventory: [], quests: {}, flags: [] };
  }
}

export function writeSave(data: SaveData): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // Quota exceeded or private browsing
  }
}