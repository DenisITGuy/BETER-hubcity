import * as THREE from 'three';
import { Input } from '../engine/Input';
import { FollowCamera } from '../engine/FollowCamera';
import { PostFX } from '../engine/PostFx';
import { generateDungeon } from './DungeonGenerator';
import { DungeonMesh } from './DungeonMesh';
import { Player } from './Player';
import { Enemy, EnemyEvents } from './Enemy';
import { ENEMIES } from './data/enemies';
import { ABILITIES } from './data/abilities';
import { Pickup } from './Pickup';
import { Hub } from './Hub';
import { Portal } from './Portal';
import { Hud } from '../ui/hud';
import { DamageNumbers } from '../ui/DamageNumbers';
import { loadSave, writeSave } from './Save';
import { COMBAT, WORLD } from './data/tunables';
import { LEVEL_TABLE, MAX_LEVEL } from './data/leveling';
import { rollLootDrop, RARITY_COLORS, RARITY_HEX, ITEMS } from '../game/items';
import { EnemyDefinition, ItemDefinition, PlayerStats } from './data/schemas';
import { Fx } from './Fx';
import { Atmosphere } from './Atmosphere';
import { ProjectilePool } from './Projectiles';
import { Npc } from './Npc';
import { NPCS } from './data/npcs';
import { DialogueUI } from '../ui/DialogueUI';
import { DIALOGUES, DialogueChoice } from './data/dialogues';
import { QuestLog, QuestEvents } from './Questlog';
import { QUESTS, ZONES, QuestDefinition } from './data/quests';

type Mode = 'hub' | 'dungeon' | 'transition';

const COLOR_HIT = '#ffffff';
const COLOR_KILL = '#ffd166';
const COLOR_HURT = '#ff5544';
const COLOR_HEAL = '#7ed957';

export class World implements EnemyEvents, QuestEvents {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly cam: FollowCamera;
  private readonly postfx: PostFX;
  private readonly input = new Input();
  private readonly hud = new Hud();
  private readonly dmgNums = new DamageNumbers();
  private readonly player = new Player();
  private readonly hub = new Hub();
  private readonly fx = new Fx();
  private readonly atmosphere = new Atmosphere();
  private readonly projectiles = new ProjectilePool();
  private readonly rushHit = new Set<Enemy>();
  private readonly npcs: Npc[] = [];
  private readonly dialogue = new DialogueUI();
  private readonly questLog = new QuestLog(this);
  private dialogueNpc: Npc | null = null;
  private readonly flags = new Set<string>();

  private dungeon!: DungeonMesh;
  private exitPortal: Portal | null = null;
  private enemies: Enemy[] = [];
  private pickups: Pickup[] = [];
  private boss: Enemy | null = null;

  private mode: Mode = 'hub';
  private depth: number;
  private cleared = false;
  private deathTimer = 0;
  private inventoryOpen = false;
  private hitStop = 0;
  private readonly focusPoint = new THREE.Vector3();
  private readonly tmp = new THREE.Vector3();

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;

    this.scene.background = new THREE.Color(0x10131f);
    this.scene.fog = new THREE.Fog(0x323d63, 25, 70);

    this.buildSky();

    this.scene.add(new THREE.HemisphereLight(0x99aadd, 0x2a3322, 0.75));
    const sun = new THREE.DirectionalLight(0xffe0b3, 2.0);
    sun.position.set(24, 36, 14);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -60;
    sun.shadow.camera.right = 60;
    sun.shadow.camera.top = 60;
    sun.shadow.camera.bottom = -60;
    sun.shadow.camera.near = 5;
    sun.shadow.camera.far = 120;
    this.scene.add(sun);
    const fill = new THREE.DirectionalLight(0x6688cc, 0.5);
    fill.position.set(-20, 18, -16);
    this.scene.add(fill);

    this.cam = new FollowCamera(canvas);
    this.postfx = new PostFX(this.renderer, this.scene, this.cam.camera, window.innerWidth, window.innerHeight);
    this.input.attachMouse(canvas);
    this.scene.add(this.player.object);
    this.scene.add(this.hub.group);
    this.scene.add(this.fx.group);
    this.scene.add(this.atmosphere.group);
    this.scene.add(this.projectiles.group);

    for (const def of NPCS) {
      const npc = new Npc(def);
      this.npcs.push(npc);
      this.hub.group.add(npc.object);
    }

    const save = loadSave();
    this.player.gold = save.gold;
    this.depth = save.depth;
    this.player.loadProgression(save.level, save.xp, save.statPoints, save.stats, save.inventory, save.equipment);
    this.questLog.load(save.quests);
    for (const f of save.flags) this.flags.add(f);

    this.player.reset(this.hub.spawn);
    this.updateHudInfo();

    window.addEventListener('resize', () => this.resize());
    this.resize();
  }

  // ----- EnemyEvents -----

  spawnProjectile(x: number, z: number, dirX: number, dirZ: number, speed: number, damage: number, color: number): void {
    this.projectiles.spawn(x, z, dirX, dirZ, speed, damage, color);
  }

  slamHit(pos: THREE.Vector3, radius: number, damage: number): void {
    this.fx.ring(pos, 0xff5533, radius, 0.35);
    this.fx.burst(pos, 0xff7744, 14, 3, 0.4, 0.5);
    this.tmp.subVectors(this.player.object.position, pos);
    this.tmp.y = 0;
    if (this.tmp.length() <= radius + this.player.radius) {
      this.player.takeDamage(damage);
      this.cam.addShake(0.22);
      this.triggerHitStop(0.09);
    } else {
      this.cam.addShake(0.08);
    }
  }

  // ----- QuestEvents -----

  toast(text: string, ms = 3000, color?: string): void {
    this.hud.toast(text, ms, color);
  }

  grantRewards(def: QuestDefinition): void {
    if (def.rewards.gold > 0) this.player.gold += def.rewards.gold;
    for (const id of def.rewards.items) {
      const item = ITEMS[id];
      if (item) this.player.addItem(item);
    }
    if (def.rewards.xp > 0) {
      const leveled = this.player.addXP(def.rewards.xp);
      if (leveled) this.hud.toast(`Level Up! You are now level ${this.player.level}`);
    }
    this.persist();
  }

  private triggerHitStop(seconds: number): void {
    this.hitStop = Math.max(this.hitStop, seconds);
  }

  // ----- Frame -----

  frame(dt: number): void {
    if (this.hitStop > 0) {
      this.hitStop -= dt;
      this.dmgNums.update(dt, this.cam.camera, window.innerWidth, window.innerHeight);
      return;
    }

    // Dialogue open: lock gameplay, run typewriter + cinematic camera only.
    if (this.dialogue.open) {
      this.dialogue.update(dt);
      if (this.input.wasPressed('Escape')) this.closeDialogue();
      this.fx.update(dt);
      this.focusPoint.copy(this.player.object.position);
      this.focusPoint.y += 1.1;
      this.cam.update(dt, this.focusPoint);
      this.atmosphere.update(dt, this.player.object.position);
      this.dmgNums.update(dt, this.cam.camera, window.innerWidth, window.innerHeight);
      return;
    }

    if (this.mode !== 'transition' && !this.player.isDead) {
      if (this.input.wasPressed('KeyI')) this.toggleInventory();
      if (this.input.wasPressed('KeyJ')) this.toggleQuestLog();
      if (this.input.wasPressed('Escape') && this.hud.questLogOpen) this.hud.closeQuestLog();
      for (let i = 0; i < ABILITIES.length; i++) {
        if (this.input.wasPressed(`Digit${i + 1}`) || this.input.wasPressed(`Numpad${i + 1}`)) {
          const def = ABILITIES[i];
          if (this.player.level < def.unlockLevel) {
            this.hud.toast(`${def.name} unlocks at level ${def.unlockLevel}`, 1600);
          } else {
            this.player.tryAbility(i, def);
          }
        }
      }
    }

    if (this.mode === 'hub') {
      this.frameHub(dt);
    } else if (this.mode === 'dungeon') {
      this.frameDungeon(dt);
    }

    this.fx.update(dt);

    if (this.player.hurtThisFrame) {
      this.cam.addShake(WORLD.shakeOnHitTaken);
      this.hud.damageFlash();
      this.fx.burst(this.player.object.position, 0xff4433, 8, 2.5, 0.35, 0.4);
      this.dmgNums.spawn(`${Math.round(this.player.lastDamageTaken)}`, this.player.object.position, COLOR_HURT, true);
      if (this.player.lastDamageTaken >= 12) this.triggerHitStop(0.09);
      this.player.hurtThisFrame = false;
    }
    if (this.player.dodgeFired) {
      this.fx.burst(this.player.object.position, 0x99aabb, 6, 2, 0.3, 0.35, -2);
    }

    this.hud.setHealth(this.player.health, this.player.derived.maxHealth);
    this.hud.setGold(this.player.gold);

    const nextLevelXP = this.player.level < MAX_LEVEL ? LEVEL_TABLE[this.player.level].xpRequired : 0;
    this.hud.setXP(this.player.xp, nextLevelXP);
    this.hud.setLevel(this.player.level, this.player.statPoints);
    this.hud.setQuestTracker(this.questLog.trackerLines());
    this.hud.setAbilitySlots(
      ABILITIES.map((def, i) => ({
        name: def.name,
        unlockLevel: def.unlockLevel,
        unlocked: this.player.level >= def.unlockLevel,
        cdFrac: this.player.abilityCooldowns[i] / def.cooldown,
        color: def.color,
      })),
    );

    this.focusPoint.copy(this.player.object.position);
    this.focusPoint.y += 1.1;
    this.cam.update(dt, this.focusPoint);
    this.atmosphere.update(dt, this.player.object.position);
    this.dmgNums.update(dt, this.cam.camera, window.innerWidth, window.innerHeight);
  }

  render(): void {
    this.postfx.render();
  }

  endFrame(): void {
    this.input.endFrame();
  }

  resize(): void {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(w, h, false);
    this.postfx.resize(w, h);
    this.cam.resize(w / h);
  }

  private buildSky(): void {
    const geo = new THREE.SphereGeometry(170, 24, 16);
    const posAttr = geo.getAttribute('position');
    const colors = new Float32Array(posAttr.count * 3);
    const top = new THREE.Color(0x1c2647);
    const horizon = new THREE.Color(0x323d63);
    const bottom = new THREE.Color(0x0e1220);
    const c = new THREE.Color();
    for (let i = 0; i < posAttr.count; i++) {
      const y = posAttr.getY(i) / 170;
      if (y >= 0) c.lerpColors(horizon, top, Math.pow(y, 0.6));
      else c.lerpColors(horizon, bottom, Math.min(1, -y * 3));
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const mat = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false });
    this.scene.add(new THREE.Mesh(geo, mat));
  }

  private toggleInventory(): void {
    if (this.inventoryOpen) {
      this.hud.closeInventory();
      this.inventoryOpen = false;
    } else {
      this.renderInventoryUI();
      this.inventoryOpen = true;
    }
  }

  private toggleQuestLog(): void {
    if (this.hud.questLogOpen) {
      this.hud.closeQuestLog();
      return;
    }
    this.hud.openQuestLog(this.questLog.panelView());
  }

  private renderInventoryUI(): void {
    this.hud.openInventory(
      {
        inventory: this.player.inventory,
        weapon: this.player.equippedWeapon,
        armor: this.player.equippedArmor,
        stats: this.player.baseStats,
        statPoints: this.player.statPoints,
      },
      (id: string) => {
        if (this.player.equip(id)) {
          this.persist();
          this.renderInventoryUI();
        }
      },
      (stat: string) => {
        if (stat === 'strength' || stat === 'vitality' || stat === 'agility' || stat === 'focus') {
          if (this.player.allocateStat(stat as keyof PlayerStats)) {
            this.persist();
            this.renderInventoryUI();
          }
        }
      },
    );
  }

  private closeInventoryNow(): void {
    if (this.inventoryOpen) {
      this.hud.closeInventory();
      this.inventoryOpen = false;
    }
  }

  private frameHub(dt: number): void {
    this.player.update(dt, this.input, this.cam.getYaw(), this.hub);
    this.hub.portal.update(dt);
    this.hub.update(dt);
    this.resolveAbilityEvents();

    // NPCs: idle life, body blocking, interaction prompt.
    let near: Npc | null = null;
    let bestDist = 1.8;
    const p = this.player.object.position;
    for (const npc of this.npcs) {
      npc.update(dt, p);
      const dx = p.x - npc.object.position.x;
      const dz = p.z - npc.object.position.z;
      const d = Math.hypot(dx, dz);
      const min = npc.radius + this.player.radius;
      if (d < min && d > 1e-4) {
        p.x += (dx / d) * (min - d);
        p.z += (dz / d) * (min - d);
      }
      if (d < bestDist) {
        bestDist = d;
        near = npc;
      }
    }
    this.hud.setInteract(near ? `[F] Talk to ${near.def.name} the ${near.def.role}` : '');
    if (near && this.input.wasPressed('KeyF')) {
      this.openDialogue(near);
    }

    // Visit-quest zones (ward stones).
    for (const id of Object.keys(ZONES)) {
      const z = ZONES[id];
      const dx = p.x - z.x;
      const dz = p.z - z.z;
      if (dx * dx + dz * dz < z.radius * z.radius) this.questLog.onZoneEnter(id);
    }

    if (this.hub.portal.contains(this.player.object.position)) {
      this.closeInventoryNow();
      this.fx.burst(this.player.object.position, 0x4488ff, 20, 3, 0.5, 0.5, 2);
      this.transitionTo('dungeon', `Depth ${this.depth}. Clear all enemies.`);
    }
  }

  private frameDungeon(dt: number): void {
    this.dungeon.update(dt);
    this.projectiles.update(dt, this.dungeon, this.player);

    if (this.player.isDead) {
      if (this.deathTimer === 0) {
        this.closeInventoryNow();
        this.hud.showOverlay('You died', 'Returning to hub...');
      }
      this.deathTimer += dt;
      this.player.updateDeath(dt);
      if (this.deathTimer >= WORLD.deathReturnDelay) {
        this.depth = 1;
        this.persist();
        this.transitionTo('hub', 'Died. Depth reset to 1.');
      }
      return;
    }

    this.player.update(dt, this.input, this.cam.getYaw(), this.dungeon);
    this.resolveAbilityEvents();
    if (this.player.attackFired) this.resolvePlayerAttack();

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];

      if (enemy.windupStarted) {
        const d = enemy.def;
        if (d.archetype === 'brute') {
          this.fx.ring(enemy.object.position, 0xff5533, d.slamRadius ?? 2.5, d.windupTime, 0.12);
        } else if (d.archetype === 'boss') {
          if (enemy.bossPattern === 0) this.fx.ring(enemy.object.position, 0xff5533, d.slamRadius ?? 3, d.windupTime, 0.12);
          else if (enemy.bossPattern === 2) this.fx.ring(enemy.object.position, 0xffd166, 1.4, d.windupTime, 0.12);
        }
      }

      const finished = enemy.update(dt, this.dungeon, this.player, this);
      if (enemy.isDead && !enemy.lootDropped) {
        enemy.lootDropped = true;
        this.questLog.onEnemyKill(enemy.def.id);
        const gold = WORLD.goldDropMin + Math.floor(Math.random() * (WORLD.goldDropMax - WORLD.goldDropMin + 1));
        const item = enemy.def.guaranteedDrop
          ? ITEMS[enemy.def.guaranteedDrop] ?? null
          : rollLootDrop(enemy.def);
        this.spawnPickup(enemy.object.position, gold, item);
        this.fx.burst(enemy.object.position, enemy.def.color, 18, 3.5, 0.6, 0.6);
        this.fx.ring(enemy.object.position, enemy.def.color, 2.2 * enemy.def.scale, 0.35);

        const leveledUp = this.player.addXP(enemy.def.xpReward);
        if (leveledUp) {
          this.hud.toast(`Level Up! You are now level ${this.player.level}`);
          this.fx.ring(this.player.object.position, 0xffd166, 4, 0.6);
          this.fx.burst(this.player.object.position, 0xffd166, 26, 3, 0.8, 0.5, 2.5);
        }
      }
      if (finished) {
        this.scene.remove(enemy.object);
        this.enemies.splice(i, 1);
      }
    }

    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const pickup = this.pickups[i];
      if (pickup.update(dt, this.player.object.position)) {
        if (pickup.gold > 0) this.player.gold += pickup.gold;
        if (pickup.item) {
          this.player.addItem(pickup.item);
          this.questLog.onCollect(pickup.item.id);
          this.hud.toast(`${pickup.item.name} picked up`, 2600, RARITY_COLORS[pickup.item.rarity]);
          this.fx.burst(pickup.object.position, RARITY_HEX[pickup.item.rarity], 14, 2.5, 0.5, 0.45, 2);
        } else {
          this.fx.burst(pickup.object.position, 0xffd166, 10, 2.5, 0.4, 0.4, 2);
        }
        this.persist();
        this.scene.remove(pickup.object);
        this.pickups.splice(i, 1);
      }
    }

    if (!this.cleared && this.enemies.length === 0) {
      this.cleared = true;
      this.exitPortal?.setActive(true);
      if (this.depth === 2) this.questLog.onZoneEnter('depth_2_exit');
      this.hud.toast('Dungeon cleared! Exit open.');
    }

    if (this.exitPortal) {
      this.exitPortal.update(dt);
      if (this.cleared && this.exitPortal.contains(this.player.object.position)) {
        this.closeInventoryNow();
        this.fx.burst(this.player.object.position, 0x66dd88, 20, 3, 0.5, 0.5, 2);
        this.depth += 1;
        this.persist();
        this.transitionTo('hub', `Run banked. Next depth: ${this.depth}`);
      }
    }

    if (this.boss && !this.boss.isDead) {
      this.hud.setBossBar(this.boss.def.name, this.boss.healthFrac, true);
    } else {
      this.hud.setBossBar('', 0, false);
    }
  }

  private resolveAbilityEvents(): void {
    const idx = this.player.abilityFired;
    if (idx >= 0) {
      this.player.abilityFired = -1;
      const def = ABILITIES[idx];
      const p = this.player.object.position;

      if (def.id === 'whirlwind') {
        const radius = def.params.radius;
        this.fx.ring(p, def.color, radius, 0.4);
        this.cam.addShake(0.12);
        let hits = 0;
        for (const enemy of this.enemies) {
          if (enemy.isDead) continue;
          this.tmp.subVectors(enemy.object.position, p);
          this.tmp.y = 0;
          const d = this.tmp.length();
          if (d > radius + enemy.radius) continue;
          this.tmp.normalize();
          const dmg = this.player.derived.meleeDamage * def.params.damageMult;
          const died = enemy.takeHit(dmg);
          this.dmgNums.spawn(`${Math.round(dmg)}`, enemy.object.position, died ? COLOR_KILL : '#66bbff', died);
          enemy.object.position.addScaledVector(this.tmp, def.params.knockback);
          this.dungeon.collideCircle(enemy.object.position, enemy.radius);
          this.fx.burst(enemy.object.position, def.color, 8, 3, 0.4, 0.5);
          hits++;
          if (died) this.triggerHitStop(0.06);
        }
        this.hud.toast(hits > 0 ? `Whirlwind hits ${hits}!` : 'Whirlwind!', 1200, '#66bbff');
      } else if (def.id === 'mend') {
        const before = this.player.health;
        this.player.heal(this.player.derived.maxHealth * def.params.healPercent);
        const gained = Math.round(this.player.health - before);
        this.tmp.copy(p);
        this.tmp.y += 1;
        this.fx.burst(this.tmp, def.color, 22, 1.6, 0.8, 0.5, 2.5);
        if (gained > 0) this.dmgNums.spawn(`+${gained}`, p, COLOR_HEAL, true);
        this.hud.toast(gained > 0 ? `Mend +${gained} HP` : 'Already at full health', 1400, '#7ed957');
      } else if (def.id === 'rush') {
        this.rushHit.clear();
        this.fx.burst(p, def.color, 8, 2, 0.3, 0.4, -1);
      }
    }

    if (this.player.isRushing || this.player.rushImpact) {
      this.player.rushImpact = false;
      const def = ABILITIES[1];
      const p = this.player.object.position;
      for (const enemy of this.enemies) {
        if (enemy.isDead || this.rushHit.has(enemy)) continue;
        this.tmp.subVectors(enemy.object.position, p);
        this.tmp.y = 0;
        const d = this.tmp.length();
        if (d > def.params.radius + enemy.radius) continue;
        this.rushHit.add(enemy);
        this.tmp.normalize();
        const dmg = this.player.derived.meleeDamage * def.params.damageMult;
        const died = enemy.takeHit(dmg);
        this.dmgNums.spawn(`${Math.round(dmg)}`, enemy.object.position, died ? COLOR_KILL : '#ffd166', died);
        enemy.object.position.addScaledVector(this.tmp, 0.5);
        this.dungeon.collideCircle(enemy.object.position, enemy.radius);
        this.fx.burst(enemy.object.position, def.color, 8, 3, 0.4, 0.5);
        this.fx.ring(p, def.color, def.params.radius * 2, 0.3);
        if (died) this.triggerHitStop(0.06);
      }
    }
  }

  // ----- Dialogue + quests -----

  private questCtx() {
    return {
      level: this.player.level,
      depth: this.depth,
      flags: this.flags,
      turnedIn: (id: string) => this.questLog.isTurnedIn(id),
    };
  }

  private openDialogue(npc: Npc): void {
    const tree = DIALOGUES[npc.def.dialogueId];
    if (!tree) {
      this.hud.toast(`${npc.def.name}: "${npc.def.greet}"`, 3500);
      return;
    }
    this.dialogueNpc = npc;
    this.hud.setInteract('');

    const start = tree.nodes[tree.startNode];
    // Inject live accept / turn-in choices for this giver.
    const extra: DialogueChoice[] = [];
    for (const def of Object.values(QUESTS)) {
      if (def.giverNpcId !== npc.def.id) continue;
      if (this.questLog.isComplete(def.id)) {
        extra.push({ label: `Turn in: ${def.title}`, action: { type: 'turnInQuest', questId: def.id } });
      } else if (this.questLog.canAccept(def.id, this.questCtx())) {
        extra.push({ label: `Accept: ${def.title}`, action: { type: 'offerQuest', questId: def.id } });
      }
    }
    const node = extra.length > 0 ? { ...start, choices: [...extra, ...start.choices] } : start;
    this.dialogue.show(node, (c) => this.handleChoice(tree.id, c));

    // Over-shoulder conversation framing.
    const npcHead = npc.object.position.clone();
    npcHead.y += 1.35;
    const playerHead = this.player.object.position.clone();
    playerHead.y += 1.3;
    const focus = npcHead.clone().lerp(playerHead, 0.35);
    const dir = playerHead.clone().sub(npcHead);
    dir.y = 0;
    if (dir.lengthSq() < 1e-6) dir.set(0, 0, 1);
    dir.normalize();
    this.cam.setCinematic(focus, Math.atan2(dir.x, dir.z), 0.22, 2.6);
  }

  private handleChoice(treeId: string, choice: DialogueChoice): void {
    if (choice.action) {
      const a = choice.action;
      if (a.type === 'shop') this.hud.toast(`(Shop '${a.shopId}' opens in Step 4)`, 2000);
      else if (a.type === 'bank') this.hud.toast('(Bank opens in Step 4)', 2000);
      else if (a.type === 'offerQuest') this.tryAcceptOrTurnIn(a.questId);
      else if (a.type === 'turnInQuest') this.tryTurnIn(a.questId);
      else if (a.type === 'setFlag') this.flags.add(a.flag);
    }
    if (choice.close || !choice.next) {
      this.closeDialogue();
      return;
    }
    const node = DIALOGUES[treeId]?.nodes[choice.next];
    if (!node) {
      this.closeDialogue();
      return;
    }
    this.dialogue.show(node, (c) => this.handleChoice(treeId, c));
  }

  private tryAcceptOrTurnIn(questId: string): void {
    if (this.questLog.isComplete(questId)) {
      this.tryTurnIn(questId);
      return;
    }
    if (this.questLog.isActive(questId)) {
      this.hud.toast('Already on that job — check the tracker.', 1800);
      return;
    }
    if (this.questLog.canAccept(questId, this.questCtx())) {
      this.questLog.accept(questId, this.player.inventory.map((i) => i.id));
      this.persist();
    } else {
      this.hud.toast('You are not ready for that task yet.', 1800);
    }
  }

  private tryTurnIn(questId: string): void {
    if (this.questLog.isComplete(questId)) {
      this.questLog.turnIn(questId);
    } else {
      this.hud.toast('Not finished yet — check the tracker.', 1800);
    }
  }

  private closeDialogue(): void {
    this.dialogue.close();
    this.cam.clearCinematic();
    this.dialogueNpc = null;
  }

  private transitionTo(target: 'hub' | 'dungeon', message?: string): void {
    if (this.mode === 'transition') return;
    this.mode = 'transition';
    this.closeDialogue();
    this.hud.closeQuestLog();
    this.hud.fadeIn();
    window.setTimeout(() => {
      if (target === 'dungeon') this.enterDungeon();
      else this.enterHub();
      this.mode = target;
      if (message) this.hud.toast(message);
      this.hud.fadeOut();
    }, 320);
  }

  private enterDungeon(): void {
    this.hub.group.visible = false;
    this.hud.hideOverlay();
    this.dmgNums.clear();
    this.loadDungeon((Math.random() * 0x7fffffff) | 0);

    const last = this.dungeon.rooms[this.dungeon.rooms.length - 1];
    this.exitPortal = new Portal(0x66dd88, false);
    this.exitPortal.object.position.copy(this.dungeon.gridToWorld(last.centerX, last.centerY));
    this.scene.add(this.exitPortal.object);

    if (this.boss) this.hud.toast(`${this.boss.def.name} guards the exit...`, 3200, '#ff8866');
    this.updateHudInfo();
  }

  private enterHub(): void {
    if (this.dungeon) this.scene.remove(this.dungeon.group);
    if (this.exitPortal) {
      this.scene.remove(this.exitPortal.object);
      this.exitPortal = null;
    }
    for (const e of this.enemies) this.scene.remove(e.object);
    for (const p of this.pickups) this.scene.remove(p.object);
    this.enemies = [];
    this.pickups = [];
    this.boss = null;
    this.cleared = false;
    this.deathTimer = 0;
    this.projectiles.clear();
    this.dmgNums.clear();
    this.hud.setBossBar('', 0, false);

    this.hub.group.visible = true;
    this.player.reset(this.hub.spawn);
    this.hud.hideOverlay();
    this.updateHudInfo();
    this.persist();
  }

  private pickEnemyDef(): EnemyDefinition {
    const r = Math.random();
    if (this.depth >= 2 && r < 0.12) return ENEMIES.brute;
    if (r < 0.32) return ENEMIES.spitter;
    return ENEMIES.slime;
  }

  private loadDungeon(seed: number): void {
    if (this.dungeon) this.scene.remove(this.dungeon.group);
    for (const e of this.enemies) this.scene.remove(e.object);
    for (const p of this.pickups) this.scene.remove(p.object);
    this.enemies = [];
    this.pickups = [];
    this.boss = null;
    this.cleared = false;
    this.projectiles.clear();

    const rooms = WORLD.roomsBase + Math.min(this.depth, WORLD.roomsDepthCap);
    const data = generateDungeon(seed, { roomCount: rooms });
    this.dungeon = new DungeonMesh(data);
    this.scene.add(this.dungeon.group);

    this.player.reset(this.dungeon.gridToWorld(data.spawnX, data.spawnY));

    for (let i = 1; i < data.rooms.length; i++) {
      const room = data.rooms[i];
      const base = 1 + (Math.random() < WORLD.packExtraChance ? 1 : 0);
      const depthBonus = Math.min(WORLD.packDepthCap, Math.floor((this.depth - 1) / WORLD.packDepthStep));
      const count = base + depthBonus;
      for (let k = 0; k < count; k++) {
        const enemy = new Enemy(this.pickEnemyDef(), room, this.dungeon.randomPointInRoom(room));
        this.enemies.push(enemy);
        this.scene.add(enemy.object);
      }
    }

    if (this.depth % 3 === 0) {
      const lastRoom = data.rooms[data.rooms.length - 1];
      this.boss = new Enemy(ENEMIES.boss_bog_king, lastRoom, this.dungeon.gridToWorld(lastRoom.centerX, lastRoom.centerY));
      this.enemies.push(this.boss);
      this.scene.add(this.boss.object);
    }
  }

  private spawnPickup(position: THREE.Vector3, gold: number, item: ItemDefinition | null): void {
    const pickup = new Pickup(position, gold, item);
    this.pickups.push(pickup);
    this.scene.add(pickup.object);
  }

  private persist(): void {
    writeSave({
      v: 3,
      gold: this.player.gold,
      depth: this.depth,
      level: this.player.level,
      xp: this.player.xp,
      statPoints: this.player.statPoints,
      stats: this.player.baseStats,
      inventory: this.player.inventory.map((i) => i.id),
      equipment: {
        weapon: this.player.equippedWeapon?.id ?? null,
        armor: this.player.equippedArmor?.id ?? null,
      },
      quests: this.questLog.serialize(),
      flags: [...this.flags],
    });
  }

  private updateHudInfo(): void {
    if (this.mode === 'hub') {
      let info = `Hub · next depth ${this.depth}`;
      if (this.player.statPoints > 0) {
        info += ` · open [I] to spend ${this.player.statPoints} pts`;
      }
      this.hud.setInfo(info);
    } else {
      this.hud.setInfo(`Depth ${this.depth}`);
    }
  }

  private resolvePlayerAttack(): void {
    const origin = this.player.attackOrigin;
    const dir = this.player.attackDir;
    const to = new THREE.Vector3();
    let hitSomething = false;

    for (const enemy of this.enemies) {
      if (enemy.isDead) continue;
      to.subVectors(enemy.object.position, origin);
      to.y = 0;
      const dist = to.length();
      if (dist > this.player.attackRange + enemy.radius) continue;
      to.normalize();
      if (to.dot(dir) < COMBAT.attackConeDot) continue;

      hitSomething = true;
      const dmg = this.player.derived.meleeDamage;
      const died = enemy.takeHit(dmg);
      this.dmgNums.spawn(`${Math.round(dmg)}`, enemy.object.position, died ? COLOR_KILL : COLOR_HIT, died);
      enemy.object.position.addScaledVector(to, COMBAT.attackKnockback);
      this.dungeon.collideCircle(enemy.object.position, enemy.radius);
      this.fx.burst(enemy.object.position, 0xffdd88, 6, 3, 0.35, 0.4);
      if (died) this.triggerHitStop(0.06);
    }

    if (hitSomething) this.cam.addShake(WORLD.shakeOnHitLanded);
  }
}