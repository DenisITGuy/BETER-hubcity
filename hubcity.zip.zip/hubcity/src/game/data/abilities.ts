import { AbilityDefinition } from './schemas';

/** Slot order = keys 1/2/3. */
export const ABILITIES: AbilityDefinition[] = [
  {
    id: 'whirlwind', name: 'Whirlwind', cooldown: 6, unlockLevel: 2, color: 0x66bbff,
    params: { radius: 3.2, damageMult: 1.2, knockback: 0.9 },
  },
  {
    id: 'rush', name: 'Rush', cooldown: 5, unlockLevel: 4, color: 0xffd166,
    params: { distance: 6, duration: 0.18, damageMult: 0.9, radius: 1.4 },
  },
  {
    id: 'mend', name: 'Mend', cooldown: 10, unlockLevel: 6, color: 0x7ed957,
    params: { healPercent: 0.35 },
  },
];