export type DialogueAction =
  | { type: 'shop'; shopId: string }
  | { type: 'bank' }
  | { type: 'offerQuest'; questId: string }
  | { type: 'turnInQuest'; questId: string }
  | { type: 'setFlag'; flag: string };

export interface DialogueChoice {
  label: string;
  next?: string;
  action?: DialogueAction;
  close?: boolean;
}

export interface DialogueNode {
  id: string;
  speaker: string;
  text: string;
  choices: DialogueChoice[];
}

export interface DialogueTree {
  id: string;
  startNode: string;
  nodes: Record<string, DialogueNode>;
}

export const DIALOGUES: Record<string, DialogueTree> = {
  dlg_fenwick: {
    id: 'dlg_fenwick',
    startNode: 'start',
    nodes: {
      start: {
        id: 'start',
        speaker: 'Old Fenwick',
        text: 'The well hummed again last night. Forty years I kept this seal quiet, and now it sings to strangers.',
        choices: [
          { label: 'What is the portal, truly?', next: 'lore' },
          { label: 'Any work for a delver?', action: { type: 'offerQuest', questId: 'mq_01_first_lantern' }, next: 'quest' },
          { label: 'Farewell.', close: true },
        ],
      },
      lore: {
        id: 'lore',
        speaker: 'Old Fenwick',
        text: 'A door is harmless until it starts choosing who may open it. This one was built to stay shut. Mind what you wake below.',
        choices: [
          { label: 'I will be careful.', next: 'start' },
          { label: 'Farewell.', close: true },
        ],
      },
      quest: {
        id: 'quest',
        speaker: 'Old Fenwick',
        text: 'Walk the old ward stones, check the seals, come back to me with your eyes open. That is all I ask.',
        choices: [{ label: 'Consider it done.', close: true }],
      },
    },
  },

  dlg_mara: {
    id: 'dlg_mara',
    startNode: 'start',
    nodes: {
      start: {
        id: 'start',
        speaker: 'Mara Emberfall',
        text: "That blade's got more rust than edge. Still, you're the sort who keeps this town breathing, so speak.",
        choices: [
          { label: 'Show me your wares.', action: { type: 'shop', shopId: 'smith' }, close: true },
          { label: 'Why do you forge for delvers?', next: 'why' },
          { label: 'Farewell.', close: true },
        ],
      },
      why: {
        id: 'why',
        speaker: 'Mara Emberfall',
        text: 'Every monster you kill down there is one less at our gates up here. Steel well spent is cheap at twice the price.',
        choices: [
          { label: 'Fair enough.', next: 'start' },
          { label: 'Farewell.', close: true },
        ],
      },
    },
  },

  dlg_ilse: {
    id: 'dlg_ilse',
    startNode: 'start',
    nodes: {
      start: {
        id: 'start',
        speaker: 'Sister Ilse',
        text: 'You carry Belowhold dust on your boots. Do not brush it off yet — I would like to look.',
        choices: [
          { label: 'What do you know of the Hollow King?', next: 'lore' },
          { label: 'I found something strange below.', action: { type: 'offerQuest', questId: 'mq_03_spitter_bile' }, next: 'quest' },
          { label: 'Farewell.', close: true },
        ],
      },
      lore: {
        id: 'lore',
        speaker: 'Sister Ilse',
        text: 'The Hollow King bound his court into stone to cheat death. Death, as ever, objected. The Belowholds are the argument, still ongoing.',
        choices: [
          { label: 'That is... not comforting.', next: 'start' },
          { label: 'Farewell.', close: true },
        ],
      },
      quest: {
        id: 'quest',
        speaker: 'Sister Ilse',
        text: 'The spitters\' bile is reactive. Not alive, exactly — more like a memory trying to digest itself. Bring me proof, and I will explain the rest.',
        choices: [{ label: 'I will collect samples.', close: true }],
      },
    },
  },

  dlg_bramble: {
    id: 'dlg_bramble',
    startNode: 'start',
    nodes: {
      start: {
        id: 'start',
        speaker: 'Bramble Tung',
        text: 'Friend! You look like someone who almost died profitably. Browse, browse — everything is nearly legal.',
        choices: [
          { label: 'Show me your goods.', action: { type: 'shop', shopId: 'general' }, close: true },
          { label: 'Heard any rumors?', next: 'rumor' },
          { label: 'Farewell.', close: true },
        ],
      },
      rumor: {
        id: 'rumor',
        speaker: 'Bramble Tung',
        text: 'Pip swears the fountain glowed on Tuesday. Telleryn says Pip owes her money. Both can be true.',
        choices: [
          { label: 'Noted. Back to business.', next: 'start' },
          { label: 'Farewell.', close: true },
        ],
      },
    },
  },

  dlg_telleryn: {
    id: 'dlg_telleryn',
    startNode: 'start',
    nodes: {
      start: {
        id: 'start',
        speaker: 'Telleryn',
        text: 'Welcome. Deposits, withdrawals, and silence — my three specialties, in that order.',
        choices: [
          { label: 'Open the bank.', action: { type: 'bank' }, close: true },
          { label: 'Do you ever worry about what we pull up from below?', next: 'worry' },
          { label: 'Farewell.', close: true },
        ],
      },
      worry: {
        id: 'worry',
        speaker: 'Telleryn',
        text: 'I worry about ledger errors. Curses are merely insurance claims with worse handwriting.',
        choices: [
          { label: 'Reassuring, in a way.', next: 'start' },
          { label: 'Farewell.', close: true },
        ],
      },
    },
  },

  dlg_pip: {
    id: 'dlg_pip',
    startNode: 'start',
    nodes: {
      start: {
        id: 'start',
        speaker: 'Pip',
        text: 'Oi! You dive, right? Right? I can tell by the haunted look. Everyone who dives gets it.',
        choices: [
          { label: 'What are people saying?', next: 'rumor' },
          { label: 'Got any jobs for me?', action: { type: 'offerQuest', questId: 'sq_collect_cloth_vests_01' }, next: 'job' },
          { label: 'Farewell.', close: true },
        ],
      },
      rumor: {
        id: 'rumor',
        speaker: 'Pip',
        text: 'They say a crowned thing walks the third dark. Fenwick says "herald." I say "payday with teeth."',
        choices: [
          { label: 'Payday with teeth. Great.', next: 'start' },
          { label: 'Farewell.', close: true },
        ],
      },
      job: {
        id: 'job',
        speaker: 'Pip',
        text: 'Two cloth vests! For orphans. Existing orphans. Probably. Bring them and I will owe you a rumor worth actual coin.',
        choices: [{ label: 'Fine. Two vests.', close: true }],
      },
    },
  },
};