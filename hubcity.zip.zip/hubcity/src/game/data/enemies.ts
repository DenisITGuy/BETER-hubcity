import { EnemyDefinition } from './schemas';

const BASIC_LOOT = [
  { itemId: 'rusty_sword', weight: 30 },
  { itemId: 'cloth_vest', weight: 30 },
  { itemId: 'iron_blade', weight: 18 },
  { itemId: 'chain_mail', weight: 14 },
  { itemId: 'ember_edge', weight: 5 },
  { itemId: 'ward_plate', weight: 3 },
];

const MID_LOOT = [
  { itemId: 'iron_blade', weight: 25 },
  { itemId: 'chain_mail', weight: 25 },
  { itemId: 'ember_edge', weight: 25 },
  { itemId: 'ward_plate', weight: 25 },
];

export const ENEMIES: Record<string, EnemyDefinition> = {
  slime: {
    id: 'slime', name: 'Green Slime', archetype: 'melee', color: 0x7ed957, scale: 1,
    health: 30, speed: 2.1, damage: 8, detectRange: 8, attackRange: 1.35, strikeRangeBonus: 0.35,
    windupTime: 0.55, recoverTime: 0.7, xpReward: 15, itemDropChance: 0.35, lootTable: BASIC_LOOT,
  },
  spitter: {
    id: 'spitter', name: 'Vile Spitter', archetype: 'spitter', color: 0xb465ff, scale: 0.9,
    health: 22, speed: 2.6, damage: 7, detectRange: 11, attackRange: 9, strikeRangeBonus: 0,
    windupTime: 0.6, recoverTime: 1.0, xpReward: 22, itemDropChance: 0.3,
    preferredRange: 6, projectileSpeed: 9, lootTable: BASIC_LOOT,
  },
  brute: {
    id: 'brute', name: 'Stone Brute', archetype: 'brute', color: 0xc07840, scale: 1.6,
    health: 90, speed: 1.4, damage: 16, detectRange: 9, attackRange: 2.2, strikeRangeBonus: 0.4,
    windupTime: 0.9, recoverTime: 1.1, xpReward: 45, itemDropChance: 0.5,
    slamRadius: 2.8, lootTable: MID_LOOT,
  },
  boss_bog_king: {
    id: 'boss_bog_king', name: 'Gulvar, the Bog King', archetype: 'boss', color: 0x58b368, scale: 2.1,
    health: 320, speed: 1.9, damage: 14, detectRange: 14, attackRange: 2.6, strikeRangeBonus: 0.4,
    windupTime: 0.7, recoverTime: 0.9, xpReward: 200, itemDropChance: 0, lootTable: [],
    slamRadius: 3.2, chargeSpeed: 10, chargeTime: 0.55, projectileSpeed: 8,
    guaranteedDrop: 'ember_edge',
  },
};