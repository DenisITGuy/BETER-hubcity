export interface LevelRequirement {
  level: number;
  xpRequired: number;
  statPointsAwarded: number;
}

/**
 * Exponential XP curve. 
 * Level 1 requires 0 XP. Level 2 requires 50 XP. Level 3 requires 125 XP, etc.
 */
export const LEVEL_TABLE: LevelRequirement[] = [
  { level: 1, xpRequired: 0, statPointsAwarded: 0 },
  { level: 2, xpRequired: 50, statPointsAwarded: 2 },
  { level: 3, xpRequired: 125, statPointsAwarded: 2 },
  { level: 4, xpRequired: 250, statPointsAwarded: 2 },
  { level: 5, xpRequired: 450, statPointsAwarded: 2 },
  { level: 6, xpRequired: 750, statPointsAwarded: 2 },
  { level: 7, xpRequired: 1150, statPointsAwarded: 2 },
  { level: 8, xpRequired: 1700, statPointsAwarded: 2 },
  { level: 9, xpRequired: 2400, statPointsAwarded: 2 },
  { level: 10, xpRequired: 3300, statPointsAwarded: 2 },
];

export const MAX_LEVEL = 10;