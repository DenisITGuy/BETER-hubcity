export interface NpcPalette {
  robe: number;
  hood: number;
  skin: number;
  accent: number;
}

export interface NpcDefinition {
  id: string;
  name: string;
  role: string;
  position: { x: number; z: number };
  facingYaw: number;
  hatStyle: 'hood' | 'hat' | 'none';
  palette: NpcPalette;
  dialogueId: string;
  /** Placeholder greet until Step 2 dialogue trees land. */
  greet: string;
  shopId?: string;
  isBank?: boolean;
}

export const NPCS: NpcDefinition[] = [
  {
    id: 'old_fenwick',
    name: 'Old Fenwick',
    role: 'Gate-Warden',
    position: { x: 2.6, z: -5.6 },
    facingYaw: 2.7,
    hatStyle: 'hood',
    palette: { robe: 0x3a5a8a, hood: 0x243a5a, skin: 0xe0b088, accent: 0xffcc66 },
    dialogueId: 'dlg_fenwick',
    greet: 'A door is harmless until it starts choosing who may open it. Mind the well, delver.',
  },
  {
    id: 'mara_emberfall',
    name: 'Mara Emberfall',
    role: 'Smith',
    position: { x: 6.5, z: 2.0 },
    facingYaw: 1.27,
    hatStyle: 'none',
    palette: { robe: 0x8a4a2a, hood: 0x5a3018, skin: 0xd9a066, accent: 0xff8844 },
    dialogueId: 'dlg_mara',
    greet: "That blade's got more rust than edge. Come back when you've got steel worth my bellows.",
    shopId: 'smith',
  },
  {
    id: 'sister_ilse',
    name: 'Sister Ilse',
    role: 'Archivist',
    position: { x: -6.8, z: 1.5 },
    facingYaw: -1.35,
    hatStyle: 'hood',
    palette: { robe: 0x6a6a72, hood: 0x4a4a52, skin: 0xc89878, accent: 0xb465ff },
    dialogueId: 'dlg_ilse',
    greet: 'The Belowholds are not caves. They are a memory trying to digest itself. Fascinating.',
  },
  {
    id: 'bramble_tung',
    name: 'Bramble Tung',
    role: 'Provisioner',
    position: { x: 3.5, z: 6.5 },
    facingYaw: 0.49,
    hatStyle: 'hat',
    palette: { robe: 0x4a7a4a, hood: 0x2f522f, skin: 0xd9a066, accent: 0x7ed957 },
    dialogueId: 'dlg_bramble',
    greet: 'Potions, patches, questionable maps! If it saves your life, it was perfectly priced.',
    shopId: 'general',
  },
  {
    id: 'telleryn',
    name: 'Telleryn',
    role: 'Banker',
    position: { x: -4.5, z: -5.0 },
    facingYaw: -2.4,
    hatStyle: 'none',
    palette: { robe: 0x2f4f4f, hood: 0x1d3333, skin: 0xe0b088, accent: 0xffd166 },
    dialogueId: 'dlg_telleryn',
    greet: 'Your gold is safer here than in your pockets, your boots, or your heroic last words.',
    isBank: true,
  },
  {
    id: 'pip',
    name: 'Pip',
    role: 'Street Scout',
    position: { x: 2.2, z: 2.0 },
    facingYaw: -0.8,
    hatStyle: 'hat',
    palette: { robe: 0x7a5a3a, hood: 0x523a24, skin: 0xc89878, accent: 0x66bbff },
    dialogueId: 'dlg_pip',
    greet: "I didn't steal that rumor. I found it unattended. Wanna hear it?",
  },
];