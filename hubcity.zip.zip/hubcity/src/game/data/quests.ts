export type QuestObjective =
  | { type: 'kill'; enemyId: string; count: number }
  | { type: 'collect'; itemId: string; count: number }
  | { type: 'visit'; zoneId: string };

export interface QuestRewards {
  xp: number;
  gold: number;
  items: string[];
}

export interface QuestPrereq {
  level?: number;
  depth?: number;
  questId?: string;
  flag?: string;
}

export interface QuestDefinition {
  id: string;
  title: string;
  giverNpcId: string;
  description: string;
  prereqs: QuestPrereq[];
  objectives: QuestObjective[];
  rewards: QuestRewards;
  nextQuestId?: string;
  isMain?: boolean;
}

/** World-space trigger circles in the hub. Dungeon zones fire from World logic. */
export const ZONES: Record<string, { x: number; z: number; radius: number }> = {
  portal_seal_north: { x: 0, z: -10.2, radius: 1.6 },
  portal_seal_south: { x: 0, z: 10.2, radius: 1.6 },
  portal_seal_west: { x: -10.2, z: 0, radius: 1.6 },
};

export const QUESTS: Record<string, QuestDefinition> = {
  sq_kill_slimes_01: {
    id: 'sq_kill_slimes_01',
    title: 'Gelatinous Housekeeping',
    giverNpcId: 'mara_emberfall',
    description: 'Slimes have been chewing boot leather and shield straps. Mara wants fewer of them.',
    prereqs: [],
    objectives: [{ type: 'kill', enemyId: 'slime', count: 8 }],
    rewards: { xp: 40, gold: 25, items: [] },
  },
  sq_kill_spitters_01: {
    id: 'sq_kill_spitters_01',
    title: 'Keep Your Distance',
    giverNpcId: 'sister_ilse',
    description: 'Ilse needs confirmation that spitter bile carries Hollow residue. Samples, of a kind.',
    prereqs: [{ level: 3 }],
    objectives: [{ type: 'kill', enemyId: 'spitter', count: 5 }],
    rewards: { xp: 60, gold: 30, items: ['iron_blade'] },
  },
  sq_collect_rusty_swords_01: {
    id: 'sq_collect_rusty_swords_01',
    title: 'Blades For The Bellows',
    giverNpcId: 'mara_emberfall',
    description: 'Mara melts bad blades into useful fittings. Bring her rusty swords.',
    prereqs: [],
    objectives: [{ type: 'collect', itemId: 'rusty_sword', count: 2 }],
    rewards: { xp: 30, gold: 40, items: [] },
  },
  sq_collect_cloth_vests_01: {
    id: 'sq_collect_cloth_vests_01',
    title: 'Patches For Pip',
    giverNpcId: 'pip',
    description: 'Pip claims the vests are for orphans. There is no evidence of this.',
    prereqs: [],
    objectives: [{ type: 'collect', itemId: 'cloth_vest', count: 2 }],
    rewards: { xp: 30, gold: 35, items: [] },
  },
  sq_visit_portal_seals_01: {
    id: 'sq_visit_portal_seals_01',
    title: 'A Walk Around The Seal',
    giverNpcId: 'old_fenwick',
    description: 'Fenwick asks you to inspect the old ward stones ringing the plaza.',
    prereqs: [],
    objectives: [
      { type: 'visit', zoneId: 'portal_seal_north' },
      { type: 'visit', zoneId: 'portal_seal_south' },
      { type: 'visit', zoneId: 'portal_seal_west' },
    ],
    rewards: { xp: 50, gold: 20, items: [] },
  },
  sq_visit_depth2_courier_01: {
    id: 'sq_visit_depth2_courier_01',
    title: 'Courier To The Second Dark',
    giverNpcId: 'bramble_tung',
    description: 'Bramble wants a package "delivered" by reaching the depth-2 exit. The package is never explained.',
    prereqs: [{ depth: 2 }],
    objectives: [{ type: 'visit', zoneId: 'depth_2_exit' }],
    rewards: { xp: 70, gold: 50, items: [] },
  },
};