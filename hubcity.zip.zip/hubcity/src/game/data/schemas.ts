export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
export type ItemSlot = 'weapon' | 'armor';

export interface ItemStatBlock {
  maxHealth?: number;
  meleeDamage?: number;
  dodgeCooldown?: number;
  abilityPower?: number;
}

export interface ItemDefinition {
  id: string;
  name: string;
  slot: ItemSlot;
  rarity: Rarity;
  stats: ItemStatBlock;
  visualColor: number;
}

export interface LootEntry {
  itemId: string;
  weight: number;
}

export type EnemyArchetype = 'melee' | 'spitter' | 'brute' | 'boss';

export interface EnemyDefinition {
  id: string;
  name: string;
  archetype: EnemyArchetype;
  color: number;
  scale: number;
  health: number;
  speed: number;
  damage: number;
  detectRange: number;
  attackRange: number;
  strikeRangeBonus: number;
  windupTime: number;
  recoverTime: number;
  xpReward: number;
  itemDropChance: number;
  lootTable: LootEntry[];
  /** Spitter: ideal firing distance. */
  preferredRange?: number;
  projectileSpeed?: number;
  /** Brute/Boss: AoE slam radius. */
  slamRadius?: number;
  /** Boss: charge dash. */
  chargeSpeed?: number;
  chargeTime?: number;
  /** Boss: item id always dropped on death. */
  guaranteedDrop?: string;
}

export interface AbilityDefinition {
  id: string;
  name: string;
  cooldown: number;
  unlockLevel: number;
  color: number;
  params: Record<string, number>;
}

export interface PlayerStats {
  strength: number;
  vitality: number;
  agility: number;
  focus: number;
}