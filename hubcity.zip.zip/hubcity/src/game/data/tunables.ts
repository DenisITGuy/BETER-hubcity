/**
 * Central gameplay tuning table — Step 0 (Phase 2).
 *
 * Rule: every number that affects feel or balance lives HERE.
 * Logic files (Player, Enemy, World, Pickup, Portal) only read from this
 * module; code never hardcodes feel.
 *
 * Values marked [tuned] changed from the Phase 1 baseline during the Step 0
 * self-evaluation pass (no playtest notes were provided):
 *  - COMBAT.attackCooldown 0.45 -> 0.38  (melee responsiveness)
 *  - ENEMY_BASE.windupTime 0.45 -> 0.55  (telegraph readability)
 * A/B these two in your next session; revert here if they read worse.
 */

export const PLAYER = {
  radius: 0.4,
  moveSpeed: 5,
  turnSmoothing: 14,
  dodgeSpeed: 13,
  dodgeTime: 0.22,
  dodgeCooldown: 0.9,
  dodgeIFrames: 0.3,
  hurtIFrames: 0.4,
  hurtFlashTime: 0.3,
  hurtFlashIntensity: 2.5,
} as const;

export const COMBAT = {
  attackCooldown: 0.38, // [tuned] was 0.45
  attackRange: 2.3,
  attackConeDot: 0.35, // dot threshold vs facing (~69° cone)
  attackDamage: 12,
  attackKnockback: 0.4,
  swingTime: 0.18,
  swingOpacity: 0.6,
} as const;

export const ENEMY_BASE = {
  radius: 0.45,
  health: 30,
  speed: 2.1,
  damage: 8,
  detectRange: 8,
  leashMultiplier: 2, // give up chase beyond detectRange * this
  attackRange: 1.35,
  strikeRangeBonus: 0.35,
  windupTime: 0.55, // [tuned] was 0.45
  recoverTime: 0.7,
  telegraphScale: 0.25,
  telegraphYScale: 0.35,
  patrolSpeedFactor: 0.45,
  patrolRetargetTime: 5,
  separation: 0.45,
  hitFlashTime: 0.15,
  deathTime: 0.35,
  hopHeight: 0.12,
  hopFrequency: 9,
  turnSmoothing: 10,
  restYSquash: 0.8,
} as const;

export const WORLD = {
  deathReturnDelay: 1.2,
  shakeOnHitTaken: 0.18,
  shakeOnHitLanded: 0.08,
  goldDropMin: 3,
  goldDropMax: 7,
  roomsBase: 6,
  roomsDepthCap: 6,
  packExtraChance: 0.5,
  packDepthStep: 2,
  packDepthCap: 2,
  pickupCollectRadius: 0.9,
  portalTriggerRadius: 1.1,
} as const;

export const DIALOGUE = {
  charsPerSecond: 45,
} as const;