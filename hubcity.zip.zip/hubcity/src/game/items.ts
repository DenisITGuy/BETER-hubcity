import { EnemyDefinition, ItemDefinition, Rarity } from '../game/data/schemas';

export const RARITY_COLORS: Record<Rarity, string> = {
  common: '#c8ccd4',
  uncommon: '#7ed957',
  rare: '#4aa3ff',
  epic: '#b465ff',
  legendary: '#ff9a3c',
};

export const RARITY_HEX: Record<Rarity, number> = {
  common: 0xc8ccd4,
  uncommon: 0x7ed957,
  rare: 0x4aa3ff,
  epic: 0xb465ff,
  legendary: 0xff9a3c,
};

export const ITEMS: Record<string, ItemDefinition> = {
  rusty_sword: {
    id: 'rusty_sword', name: 'Rusty Sword', slot: 'weapon', rarity: 'common',
    stats: { meleeDamage: 2 }, visualColor: 0x9a8f7d,
  },
  iron_blade: {
    id: 'iron_blade', name: 'Iron Blade', slot: 'weapon', rarity: 'uncommon',
    stats: { meleeDamage: 5 }, visualColor: 0xcfd6e0,
  },
  ember_edge: {
    id: 'ember_edge', name: 'Ember Edge', slot: 'weapon', rarity: 'rare',
    stats: { meleeDamage: 9, abilityPower: 5 }, visualColor: 0xff6a3c,
  },
  cloth_vest: {
    id: 'cloth_vest', name: 'Cloth Vest', slot: 'armor', rarity: 'common',
    stats: { maxHealth: 15 }, visualColor: 0x6b7a8f,
  },
  chain_mail: {
    id: 'chain_mail', name: 'Chain Mail', slot: 'armor', rarity: 'uncommon',
    stats: { maxHealth: 35 }, visualColor: 0x8f97a6,
  },
  // Heavy plate: big HP, but slows your dodge. Trade-offs are the point.
  ward_plate: {
    id: 'ward_plate', name: 'Ward Plate', slot: 'armor', rarity: 'rare',
    stats: { maxHealth: 60, dodgeCooldown: 0.1 }, visualColor: 0x5f7fd0,
  },
};

/** Rarity-weighted loot roll for an enemy definition. Returns null on no drop. */
export function rollLootDrop(def: EnemyDefinition): ItemDefinition | null {
  if (Math.random() >= def.itemDropChance) return null;
  const total = def.lootTable.reduce((sum, e) => sum + e.weight, 0);
  if (total <= 0) return null;
  let roll = Math.random() * total;
  for (const entry of def.lootTable) {
    roll -= entry.weight;
    if (roll <= 0) return ITEMS[entry.itemId] ?? null;
  }
  return null;
}