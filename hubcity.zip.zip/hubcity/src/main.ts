import { GameLoop } from './engine/GameLoop';
import { World } from './game/World';

const canvas = document.getElementById('game');
if (!(canvas instanceof HTMLCanvasElement)) {
  throw new Error('Missing #game canvas');
}

const world = new World(canvas);
const loop = new GameLoop((dt) => {
  world.frame(dt);
  world.render();
  world.endFrame();
});
loop.start();