import * as THREE from 'three';

interface DmgNum {
  el: HTMLDivElement;
  pos: THREE.Vector3;
  life: number;
  maxLife: number;
  vy: number;
  active: boolean;
}

const POOL = 24;

/** Pooled floating combat text. Zero allocations in steady state. */
export class DamageNumbers {
  private readonly root: HTMLDivElement;
  private readonly nums: DmgNum[] = [];
  private readonly tmp = new THREE.Vector3();

  constructor() {
    this.root = document.createElement('div');
    this.root.style.cssText = 'position:fixed;inset:0;pointer-events:none;overflow:hidden;z-index:5;';
    document.body.appendChild(this.root);
    for (let i = 0; i < POOL; i++) {
      const el = document.createElement('div');
      el.style.cssText =
        'position:absolute;left:0;top:0;font-family:system-ui,sans-serif;font-weight:700;font-size:16px;' +
        'text-shadow:0 2px 3px rgba(0,0,0,0.85);opacity:0;will-change:transform,opacity;white-space:nowrap;';
      this.root.appendChild(el);
      this.nums.push({ el, pos: new THREE.Vector3(), life: 0, maxLife: 0.9, vy: 0, active: false });
    }
  }

  spawn(text: string, worldPos: THREE.Vector3, color: string, big = false): void {
    for (const n of this.nums) {
      if (n.active) continue;
      n.active = true;
      n.life = 0;
      n.maxLife = 0.9;
      n.vy = 1.6;
      n.pos.copy(worldPos);
      n.pos.y += 1.7;
      n.el.textContent = text;
      n.el.style.color = color;
      n.el.style.fontSize = big ? '24px' : '16px';
      n.el.style.opacity = '1';
      return;
    }
  }

  update(dt: number, camera: THREE.Camera, w: number, h: number): void {
    for (const n of this.nums) {
      if (!n.active) continue;
      n.life += dt;
      const t = n.life / n.maxLife;
      if (t >= 1) {
        n.active = false;
        n.el.style.opacity = '0';
        continue;
      }
      n.pos.y += n.vy * dt;
      n.vy *= Math.exp(-3 * dt);
      this.tmp.copy(n.pos).project(camera);
      if (this.tmp.z > 1) {
        n.el.style.opacity = '0'; // behind camera
        continue;
      }
      const x = (this.tmp.x * 0.5 + 0.5) * w;
      const y = (-this.tmp.y * 0.5 + 0.5) * h;
      n.el.style.transform = `translate(${x}px, ${y}px) translate(-50%, -100%)`;
      n.el.style.opacity = `${1 - t * t}`;
    }
  }

  clear(): void {
    for (const n of this.nums) {
      n.active = false;
      n.el.style.opacity = '0';
    }
  }
}