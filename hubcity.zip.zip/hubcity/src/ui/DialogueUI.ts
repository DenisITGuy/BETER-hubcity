import { DialogueChoice, DialogueNode } from '../game/data/dialogues';
import { DIALOGUE } from '../game/data/tunables';

/** DOM dialogue box: speaker, typewriter text (click to skip), choice buttons. */
export class DialogueUI {
  readonly root: HTMLDivElement;
  private readonly speakerEl: HTMLDivElement;
  private readonly textEl: HTMLDivElement;
  private readonly choicesEl: HTMLDivElement;

  private fullText = '';
  private shown = 0;
  private typing = false;
  private choices: DialogueChoice[] = [];
  private onChoice: ((c: DialogueChoice) => void) | null = null;
  open = false;

  constructor() {
    this.root = document.createElement('div');
    this.root.style.cssText =
      'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);width:min(680px,92vw);' +
      'background:rgba(12,15,22,0.94);border:1px solid #3a4157;border-radius:10px;padding:14px 18px;' +
      'display:none;pointer-events:auto;font-family:system-ui,sans-serif;color:#e6e9f0;z-index:6;';

    this.speakerEl = document.createElement('div');
    this.speakerEl.style.cssText =
      'font-size:13px;letter-spacing:1px;text-transform:uppercase;color:#ffd166;margin-bottom:6px;';

    this.textEl = document.createElement('div');
    this.textEl.style.cssText = 'font-size:15px;line-height:1.45;min-height:44px;cursor:pointer;';

    this.choicesEl = document.createElement('div');
    this.choicesEl.style.cssText = 'display:flex;flex-direction:column;gap:6px;margin-top:10px;';

    this.root.append(this.speakerEl, this.textEl, this.choicesEl);
    document.body.appendChild(this.root);

    this.textEl.addEventListener('click', () => {
      if (this.typing) this.finishTyping();
    });
  }

  show(node: DialogueNode, onChoice: (c: DialogueChoice) => void): void {
    this.open = true;
    this.onChoice = onChoice;
    this.speakerEl.textContent = node.speaker;
    this.fullText = node.text;
    this.shown = 0;
    this.typing = true;
    this.choices = node.choices;
    this.textEl.textContent = '';
    this.choicesEl.innerHTML = '';
    this.root.style.display = 'block';
  }

  update(dt: number): void {
    if (!this.open || !this.typing) return;
    this.shown += DIALOGUE.charsPerSecond * dt;
    if (this.shown >= this.fullText.length) this.finishTyping();
    else this.textEl.textContent = this.fullText.slice(0, Math.floor(this.shown));
  }

  private finishTyping(): void {
    this.typing = false;
    this.textEl.textContent = this.fullText;
    this.renderChoices();
  }

  private renderChoices(): void {
    this.choicesEl.innerHTML = '';
    for (const choice of this.choices) {
      const btn = document.createElement('button');
      btn.textContent = choice.label;
      btn.style.cssText =
        'text-align:left;background:#2a3145;color:#e6e9f0;border:1px solid #3a4157;border-radius:6px;' +
        'padding:7px 12px;font-size:14px;cursor:pointer;';
      btn.addEventListener('mouseenter', () => {
        btn.style.background = '#3a4157';
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.background = '#2a3145';
      });
      btn.addEventListener('click', () => {
        if (this.onChoice) this.onChoice(choice);
      });
      this.choicesEl.appendChild(btn);
    }
  }

  close(): void {
    this.open = false;
    this.onChoice = null;
    this.root.style.display = 'none';
  }
}