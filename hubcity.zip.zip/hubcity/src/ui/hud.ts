﻿import { ItemDefinition, PlayerStats } from '../game/data/schemas';
import { RARITY_COLORS } from '../game/items';
import { QuestPanelEntry } from '../game/Questlog';

function el(id: string): HTMLElement {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing HUD element #${id}`);
  return node;
}

export interface InventoryView {
  inventory: ItemDefinition[];
  weapon: ItemDefinition | null;
  armor: ItemDefinition | null;
  stats: PlayerStats;
  statPoints: number;
}

export interface AbilitySlotState {
  name: string;
  unlockLevel: number;
  unlocked: boolean;
  cdFrac: number;
  color: number;
}

export class Hud {
  private hpFill = el('hp-fill');
  private xpFill = el('xp-fill');
  private goldLabel = el('gold');
  private levelLabel = el('level');
  private infoLabel = el('seed');
  private overlay = el('overlay');
  private overlayTitle = el('overlay-title');
  private overlayBody = el('overlay-body');
  private damageFlashEl = el('damage-flash');
  private fadeEl = el('fade');
  private toastEl = el('toast');
  private inventoryEl = el('inventory');
  private bossWrap = el('boss-wrap');
  private interactEl = el('interact');
  private questTrackerEl = el('quest-tracker');
  private questLogEl = el('questlog');
  private lastTracker = '';
  questLogOpen = false;
  private bossName = el('boss-name');
  private bossFill = el('boss-fill');
  private readonly abilitySlots = [0, 1, 2].map((i) => ({
    root: el(`ab-${i}`),
    cd: el(`ab-${i}-cd`),
    name: el(`ab-${i}-name`),
  }));

  private lastGold = -1;
  private flashTimer = 0;
  private toastTimer = 0;
  private bossVisible = false;
  private onEquipCallback: ((id: string) => void) | null = null;
  private onAllocCallback: ((stat: string) => void) | null = null;

  constructor() {
    this.inventoryEl.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      const equipId = target.getAttribute('data-equip');
      if (equipId && this.onEquipCallback) {
        this.onEquipCallback(equipId);
        return;
      }
      const alloc = target.getAttribute('data-alloc');
      if (alloc && this.onAllocCallback) this.onAllocCallback(alloc);
    });
  }

  setHealth(current: number, max: number): void {
    this.hpFill.style.width = `${Math.max(0, (current / max) * 100)}%`;
  }

  setXP(current: number, max: number): void {
    this.xpFill.style.width = max <= 0 ? '100%' : `${Math.max(0, (current / max) * 100)}%`;
  }

  setLevel(level: number, statPoints: number): void {
    this.levelLabel.textContent = `Lvl ${level}` + (statPoints > 0 ? ` (${statPoints} pts)` : '');
  }

  setGold(gold: number): void {
    if (gold === this.lastGold) return;
    this.lastGold = gold;
    this.goldLabel.textContent = `Gold ${gold}`;
  }

    setInfo(text: string): void {
    this.infoLabel.textContent = text;
  }

  setInteract(text: string): void {
    if (text === '') {
      this.interactEl.style.opacity = '0';
    } else {
      this.interactEl.textContent = text;
      this.interactEl.style.opacity = '1';
    }
  }

  setQuestTracker(lines: string[]): void {
    const key = lines.join('|');
    if (key === this.lastTracker) return;
    this.lastTracker = key;
    if (lines.length === 0) {
      this.questTrackerEl.style.opacity = '0';
      return;
    }
    this.questTrackerEl.innerHTML = lines
      .map((l) =>
        l.startsWith('  ') ? `<div class="qt-line">${l.trim()}</div>` : `<div class="qt-title">${l}</div>`,
      )
      .join('');
    this.questTrackerEl.style.opacity = '0.95';
  }

  openQuestLog(entries: QuestPanelEntry[]): void {
    const body =
      entries.length === 0
        ? '<div class="ql-empty">No quests yet. Talk to the townsfolk.</div>'
        : entries
            .map(
              (e) =>
                `<div class="ql-entry"><div class="ql-title">${e.title} <span class="ql-state">[${e.state}]</span></div>` +
                `<div class="ql-desc">${e.description}</div>` +
                e.lines.map((l) => `<div class="ql-line">${l}</div>`).join('') +
                '</div>',
            )
            .join('');
    this.questLogEl.innerHTML = `<h2>Quest Log</h2>${body}<div class="inv-hint">[J] close</div>`;
    this.questLogEl.style.display = 'block';
    this.questLogOpen = true;
  }

  closeQuestLog(): void {
    this.questLogEl.style.display = 'none';
    this.questLogOpen = false;
  }

  setBossBar(name: string, frac: number, visible: boolean): void {
    if (visible !== this.bossVisible) {
      this.bossVisible = visible;
      this.bossWrap.style.display = visible ? 'block' : 'none';
    }
    if (visible) {
      this.bossName.textContent = name;
      this.bossFill.style.width = `${Math.max(0, frac * 100)}%`;
    }
  }

  setAbilitySlots(states: AbilitySlotState[]): void {
    for (let i = 0; i < this.abilitySlots.length && i < states.length; i++) {
      const s = states[i];
      const slot = this.abilitySlots[i];
      const css = `#${s.color.toString(16).padStart(6, '0')}`;
      slot.root.style.borderColor = s.unlocked ? css : '#3a4157';
      slot.root.style.opacity = s.unlocked ? '1' : '0.45';
      slot.cd.style.height = `${Math.max(0, Math.min(1, s.cdFrac)) * 100}%`;
      slot.name.textContent = s.unlocked ? s.name : `Lv ${s.unlockLevel}`;
      slot.name.style.color = css;
    }
  }

  showOverlay(title: string, body: string): void {
    this.overlayTitle.textContent = title;
    this.overlayBody.textContent = body;
    this.overlay.style.display = 'flex';
  }

  hideOverlay(): void {
    this.overlay.style.display = 'none';
  }

  damageFlash(): void {
    this.damageFlashEl.classList.add('on');
    window.clearTimeout(this.flashTimer);
    this.flashTimer = window.setTimeout(() => this.damageFlashEl.classList.remove('on'), 130);
  }

  fadeIn(): void {
    this.fadeEl.classList.add('on');
  }

  fadeOut(): void {
    this.fadeEl.classList.remove('on');
  }

  toast(text: string, ms = 3000, color?: string): void {
    this.toastEl.textContent = text;
    this.toastEl.style.color = color ?? '#e6e9f0';
    this.toastEl.classList.add('on');
    window.clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => this.toastEl.classList.remove('on'), ms);
  }

  openInventory(view: InventoryView, onEquip: (id: string) => void, onAlloc: (stat: string) => void): void {
    this.onEquipCallback = onEquip;
    this.onAllocCallback = onAlloc;

    const statText = (item: ItemDefinition): string => {
      const parts: string[] = [];
      if (item.stats.maxHealth) parts.push(`HP +${item.stats.maxHealth}`);
      if (item.stats.meleeDamage) parts.push(`DMG +${item.stats.meleeDamage}`);
      if (item.stats.dodgeCooldown) parts.push(`Dodge ${item.stats.dodgeCooldown > 0 ? '+' : ''}${item.stats.dodgeCooldown}s`);
      if (item.stats.abilityPower) parts.push(`Power +${item.stats.abilityPower}`);
      return parts.join(', ');
    };

    const colored = (item: ItemDefinition | null): string =>
      item ? `<span style="color:${RARITY_COLORS[item.rarity]}">${item.name}</span>` : '<span style="opacity:0.5">—</span>';

    const row = (item: ItemDefinition): string =>
      `<div class="inv-row"><span style="color:${RARITY_COLORS[item.rarity]}">${item.name}</span>` +
      `<span class="inv-tag">${item.rarity} · ${statText(item)}</span>` +
      `<button data-equip="${item.id}">Equip</button></div>`;

    const plus = (stat: string): string =>
      view.statPoints > 0 ? `<button data-alloc="${stat}">+</button>` : '';

    this.inventoryEl.innerHTML =
      `<h2>Inventory</h2>` +
      `<div class="inv-section">Equipped</div>` +
      `<div class="inv-row"><span>Weapon</span>${colored(view.weapon)}</div>` +
      `<div class="inv-row"><span>Armor</span>${colored(view.armor)}</div>` +
      `<div class="inv-section">Attributes (${view.statPoints} pts)</div>` +
      `<div class="inv-row"><span>Strength ${view.stats.strength}</span><span class="inv-tag">+2 DMG</span>${plus('strength')}</div>` +
      `<div class="inv-row"><span>Vitality ${view.stats.vitality}</span><span class="inv-tag">+10 HP</span>${plus('vitality')}</div>` +
      `<div class="inv-row"><span>Agility ${view.stats.agility}</span><span class="inv-tag">-5% dodge CD</span>${plus('agility')}</div>` +
      `<div class="inv-row"><span>Focus ${view.stats.focus}</span><span class="inv-tag">+5 Power</span>${plus('focus')}</div>` +
      `<div class="inv-section">Backpack (${view.inventory.length})</div>` +
      (view.inventory.length > 0
        ? view.inventory.map(row).join('')
        : `<div class="inv-row"><span style="opacity:0.6">Empty — slimes drop gear sometimes.</span></div>`) +
      `<div class="inv-hint">[I] close</div>`;

    this.inventoryEl.style.display = 'block';
  }

  closeInventory(): void {
    this.inventoryEl.style.display = 'none';
    this.onEquipCallback = null;
    this.onAllocCallback = null;
  }
}